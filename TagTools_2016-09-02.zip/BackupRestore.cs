﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace MusicBeePlugin
{
    public class BackupDateType
    {
        public DateTime creationDate;
        public string guid;

        public BackupDateType()
        {
            creationDate = DateTime.UtcNow;
            guid = Guid.NewGuid().ToString();
        }

        public BackupDateType(BackupDateType source)
        {
            creationDate = source.creationDate;
            guid = source.guid;
        }

        public virtual void save(string fileName)
        {
            System.IO.Stream stream = System.IO.File.Open(fileName + ".mbd", System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None);
            System.IO.StreamWriter file = new System.IO.StreamWriter(stream, Encoding.UTF8);

            System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(BackupDateType));

            serializer.Serialize(file, this);

            file.Close();
        }

        public virtual void load(string fileName)
        {
            System.IO.FileStream stream = System.IO.File.Open(fileName + ".mbd", System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.None);
            System.IO.StreamReader file = new System.IO.StreamReader(stream, Encoding.UTF8);

            System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(BackupDateType));

            BackupDateType backupDate = (BackupDateType)serializer.Deserialize(file);

            file.Close();

            
            creationDate = backupDate.creationDate;
            guid = backupDate.guid;
        }
    }

    public class BackupType : BackupDateType
    {
        public int xSize;
        public int ySize;
        public string[] values;

        public BackupType()
        {
            return;
        }

        public BackupType(int xSizeParam, int ySizeParam)
        {
            guid = Guid.NewGuid().ToString();
            xSize = xSizeParam;
            ySize = ySizeParam;
            values = new string[xSizeParam * ySizeParam];
        }

        public override void save(string fileName)
        {
            System.IO.Stream stream = System.IO.File.Open(fileName + ".xml", System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None);
            System.IO.StreamWriter file = new System.IO.StreamWriter(stream, Encoding.UTF8);

            System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(BackupType));

            serializer.Serialize(file, this);

            file.Close();
        }

        public override void load(string fileName)
        {
            System.IO.FileStream stream = System.IO.File.Open(fileName + ".xml", System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.None);
            System.IO.StreamReader file = new System.IO.StreamReader(stream, Encoding.UTF8);

            System.Xml.Serialization.XmlSerializer backupSerializer = new System.Xml.Serialization.XmlSerializer(typeof(BackupType));
            BackupType backup = (BackupType)backupSerializer.Deserialize(file);

            file.Close();


            creationDate = backup.creationDate;
            guid = backup.guid;
            xSize = backup.xSize;
            ySize = backup.ySize;
            values = backup.values;
        }

        public string getValue(int xParam, int yParam)
        {
            string value = values[xParam * ySize + yParam];
            if (value != null)
            {
                value = Regex.Replace(value, "\ufffa", "\u0000");
                value = Regex.Replace(value, "\ufffb", "\u0001");
                value = Regex.Replace(value, "\ufffc", "\u0002");
                value = Regex.Replace(value, "\ufffd", "\u0003");
            }

            return "" + value;
        }

        public void setValue(string valueParam, int xParam, int yParam)
        {
            if (valueParam != null)
            {
                valueParam = Regex.Replace(valueParam, "\u0000", "\ufffa");
                valueParam = Regex.Replace(valueParam, "\u0001", "\ufffb");
                valueParam = Regex.Replace(valueParam, "\u0002", "\ufffc");
                valueParam = Regex.Replace(valueParam, "\u0003", "\ufffd");
            }

            values[xParam * ySize + yParam] = valueParam;
        }

        public int getBound(int i)
        {
            if (i == 0)
                return xSize;
            else
                return ySize;
        }
    }

    public class BackupIndexType
    {
        public int numberOfTracks;
        public List<List<string>> backups;

        public BackupIndexType()
        {
            numberOfTracks = 0;
            backups = new List<List<string>>();
        }

        public BackupIndexType(BackupIndexDictionary dictionary)
        {
            backups = new List<List<string>>();
            numberOfTracks = dictionary.Count;

            if (dictionary.Count == 0)
                return;

            foreach (var trackBackupsWithIds in dictionary)
            {
                List<string> trackBackupsList = new List<string>();

                bool trackIdIsNotAdded = true;
                foreach (var trackBackups in trackBackupsWithIds.Value)
                {
                    if (trackIdIsNotAdded)
                    {
                        trackBackupsList.Add(trackBackupsWithIds.Key);
                        trackIdIsNotAdded = false;
                    }

                    trackBackupsList.Add(trackBackups.Key);
                }

                backups.Add(trackBackupsList);
            }
        }

        public BackupIndexDictionary copyToBackupIndexDictionary()
        {
            BackupIndexDictionary dictionary = new BackupIndexDictionary();

            foreach (var trackBackups in backups)
            {
                SortedDictionary<string, bool> trackBackupIndex = new SortedDictionary<string, bool>();

                string trackId = null;
                foreach (var trackBackup in trackBackups)
                {
                    if (trackId == null)
                    {
                        trackId = trackBackup;
                    }
                    else
                    {
                        trackBackupIndex.Add(trackBackup, true);
                    }
                }

                dictionary.Add(trackId, trackBackupIndex);
            }

            return dictionary;
        }
    }

    public class BackupIndexDictionary : SortedDictionary<string, SortedDictionary<string, bool>>
    {
        public void saveBackup(string backupName)
        {
            if (Plugin.MbApiInterface.Library_QueryFiles("domain=Library"))
            {
                string currentFile;
                string trackId;

                string[] files = Plugin.MbApiInterface.Library_QueryGetAllFiles().Split(Plugin.FilesSeparators, StringSplitOptions.RemoveEmptyEntries);


                List<string> tagNames = new List<string>();
                Plugin.FillList(tagNames, false, true, false);

                List<Plugin.MetaDataType> tagIds = new List<Plugin.MetaDataType>();
                for (int i = 0; i < tagNames.Count; i++)
                    tagIds.Add(Plugin.GetTagId(tagNames[i]));

                BackupType backup = new BackupType(files.Length, tagIds.Count * 2 + 1);

                for (int fileCounter = 0; fileCounter < files.Length; fileCounter++)
                {
                    currentFile = files[fileCounter];
                    trackId = ""; //******

                    backup.setValue(trackId, fileCounter, 0);
                    for (int i = 0; i < tagIds.Count; i++)
                    {
                        backup.setValue(((int)tagIds[i]).ToString(), fileCounter, 2 * i + 1);
                        backup.setValue(Plugin.MbApiInterface.Library_GetFileTag(currentFile, tagIds[i]), fileCounter, 2 * i + 2);
                    }

                    SortedDictionary<string, bool> trackBackups;
                    if (!TryGetValue(trackId, out trackBackups))
                    {
                        trackBackups = new SortedDictionary<string, bool>();
                        Add(trackId, trackBackups);
                    }

                    bool placeholder;
                    if (!trackBackups.TryGetValue(backup.guid, out placeholder))
                        trackBackups.Add(backup.guid, true);
                }

                backup.save(backupName);

                BackupDateType backupDate = new BackupDateType(backup);
                backupDate.save(backupName);
            }


            BackupIndexType backupIndex = new BackupIndexType(this);

            System.IO.FileStream stream = System.IO.File.Open(Plugin.BackupIndexFileName, System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None);
            System.IO.StreamWriter file = new System.IO.StreamWriter(stream, Encoding.UTF8);

            System.Xml.Serialization.XmlSerializer backupIndexSerializer = new System.Xml.Serialization.XmlSerializer(typeof(BackupIndexType));

            backupIndexSerializer.Serialize(file, backupIndex);

            file.Close();
        }

        public void deleteBackup(BackupDateType backup)
        {
            string backupGuid = null;
            KeyValuePair<string, SortedDictionary<string, bool>> foundTrackBackups = new KeyValuePair<string, SortedDictionary<string, bool>>();

            foreach (var trackBackups in this)
            {
                bool placeholder;
                if (trackBackups.Value.TryGetValue(backup.guid, out placeholder))
                {
                    backupGuid = backup.guid;
                    foundTrackBackups = trackBackups;
                    break;
                }
            }

            if (backupGuid != null)
            {
                foundTrackBackups.Value.Remove(backupGuid);

                if (foundTrackBackups.Value.Count == 0)
                    Remove(foundTrackBackups.Key);
            }


            BackupIndexType backupIndex = new BackupIndexType(this);

            System.IO.FileStream stream = System.IO.File.Open(Plugin.BackupIndexFileName, System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None);
            System.IO.StreamWriter file = new System.IO.StreamWriter(stream, Encoding.UTF8);

            System.Xml.Serialization.XmlSerializer backupIndexSerializer = new System.Xml.Serialization.XmlSerializer(typeof(BackupIndexType));

            backupIndexSerializer.Serialize(file, backupIndex);

            file.Close();
        }
    }
}
