﻿namespace MusicBeePlugin
{
    partial class ASRPresetEditor
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ASRPresetEditor));
            this.label1 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.descriptionBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.searchedPatternBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.searchedTagList = new System.Windows.Forms.ComboBox();
            this.replacedTagList = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.replacedPatternBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonApply = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.ignoreCaseCheckBox = new System.Windows.Forms.CheckBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.appendCheckBox = new System.Windows.Forms.CheckBox();
            this.customTextBox = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.append2CheckBox = new System.Windows.Forms.CheckBox();
            this.searchedPattern2Box = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.replacedPattern2Box = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.replacedTag2List = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.searchedTag2List = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.append3CheckBox = new System.Windows.Forms.CheckBox();
            this.searchedPattern3Box = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.replacedPattern3Box = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.replacedTag3List = new System.Windows.Forms.ComboBox();
            this.searchedTag3List = new System.Windows.Forms.ComboBox();
            this.languages = new System.Windows.Forms.ComboBox();
            this.guidBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.modifiedBox = new System.Windows.Forms.TextBox();
            this.modifiedByUserCheckBox = new System.Windows.Forms.CheckBox();
            this.parameterTagTypeList = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.parameterTag2TypeList = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.parameterTag3TypeList = new System.Windows.Forms.ComboBox();
            this.customTextCheckBox = new System.Windows.Forms.CheckBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.customText2CheckBox = new System.Windows.Forms.CheckBox();
            this.customText2Box = new System.Windows.Forms.TextBox();
            this.customText4CheckBox = new System.Windows.Forms.CheckBox();
            this.customText4Box = new System.Windows.Forms.TextBox();
            this.customText3CheckBox = new System.Windows.Forms.CheckBox();
            this.customText3Box = new System.Windows.Forms.TextBox();
            this.append4CheckBox = new System.Windows.Forms.CheckBox();
            this.append5CheckBox = new System.Windows.Forms.CheckBox();
            this.parameterTag3List = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.parameterTag2List = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.parameterTagList = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.parameterTag6List = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.parameterTag5List = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.parameterTag4List = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.parameterTag6TypeList = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.parameterTag5TypeList = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.parameterTag4TypeList = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.searchedPattern4Box = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.replacedPattern4Box = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.replacedTag4List = new System.Windows.Forms.ComboBox();
            this.searchedTag4List = new System.Windows.Forms.ComboBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.searchedPattern5Box = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.replacedPattern5Box = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.replacedTag5List = new System.Windows.Forms.ComboBox();
            this.searchedTag5List = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            this.toolTip1.SetToolTip(this.label1, resources.GetString("label1.ToolTip"));
            // 
            // nameBox
            // 
            resources.ApplyResources(this.nameBox, "nameBox");
            this.nameBox.Name = "nameBox";
            this.toolTip1.SetToolTip(this.nameBox, resources.GetString("nameBox.ToolTip"));
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            this.toolTip1.SetToolTip(this.label2, resources.GetString("label2.ToolTip"));
            // 
            // descriptionBox
            // 
            resources.ApplyResources(this.descriptionBox, "descriptionBox");
            this.descriptionBox.Name = "descriptionBox";
            this.toolTip1.SetToolTip(this.descriptionBox, resources.GetString("descriptionBox.ToolTip"));
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            this.toolTip1.SetToolTip(this.label3, resources.GetString("label3.ToolTip"));
            // 
            // searchedPatternBox
            // 
            resources.ApplyResources(this.searchedPatternBox, "searchedPatternBox");
            this.searchedPatternBox.Name = "searchedPatternBox";
            this.toolTip1.SetToolTip(this.searchedPatternBox, resources.GetString("searchedPatternBox.ToolTip"));
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            this.toolTip1.SetToolTip(this.label4, resources.GetString("label4.ToolTip"));
            // 
            // searchedTagList
            // 
            resources.ApplyResources(this.searchedTagList, "searchedTagList");
            this.searchedTagList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchedTagList.DropDownWidth = 250;
            this.searchedTagList.FormattingEnabled = true;
            this.searchedTagList.Name = "searchedTagList";
            this.toolTip1.SetToolTip(this.searchedTagList, resources.GetString("searchedTagList.ToolTip"));
            // 
            // replacedTagList
            // 
            resources.ApplyResources(this.replacedTagList, "replacedTagList");
            this.replacedTagList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.replacedTagList.DropDownWidth = 250;
            this.replacedTagList.FormattingEnabled = true;
            this.replacedTagList.Name = "replacedTagList";
            this.toolTip1.SetToolTip(this.replacedTagList, resources.GetString("replacedTagList.ToolTip"));
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            this.toolTip1.SetToolTip(this.label5, resources.GetString("label5.ToolTip"));
            // 
            // replacedPatternBox
            // 
            resources.ApplyResources(this.replacedPatternBox, "replacedPatternBox");
            this.replacedPatternBox.Name = "replacedPatternBox";
            this.toolTip1.SetToolTip(this.replacedPatternBox, resources.GetString("replacedPatternBox.ToolTip"));
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            this.toolTip1.SetToolTip(this.label6, resources.GetString("label6.ToolTip"));
            // 
            // buttonApply
            // 
            resources.ApplyResources(this.buttonApply, "buttonApply");
            this.buttonApply.Name = "buttonApply";
            this.toolTip1.SetToolTip(this.buttonApply, resources.GetString("buttonApply.ToolTip"));
            this.buttonApply.UseVisualStyleBackColor = true;
            this.buttonApply.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // buttonCancel
            // 
            resources.ApplyResources(this.buttonCancel, "buttonCancel");
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Name = "buttonCancel";
            this.toolTip1.SetToolTip(this.buttonCancel, resources.GetString("buttonCancel.ToolTip"));
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // ignoreCaseCheckBox
            // 
            resources.ApplyResources(this.ignoreCaseCheckBox, "ignoreCaseCheckBox");
            this.ignoreCaseCheckBox.Name = "ignoreCaseCheckBox";
            this.toolTip1.SetToolTip(this.ignoreCaseCheckBox, resources.GetString("ignoreCaseCheckBox.ToolTip"));
            this.ignoreCaseCheckBox.UseVisualStyleBackColor = true;
            // 
            // linkLabel1
            // 
            resources.ApplyResources(this.linkLabel1, "linkLabel1");
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.TabStop = true;
            this.toolTip1.SetToolTip(this.linkLabel1, resources.GetString("linkLabel1.ToolTip"));
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // groupBox1
            // 
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Controls.Add(this.appendCheckBox);
            this.groupBox1.Controls.Add(this.searchedPatternBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.replacedPatternBox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.replacedTagList);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.searchedTagList);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBox1, resources.GetString("groupBox1.ToolTip"));
            // 
            // appendCheckBox
            // 
            resources.ApplyResources(this.appendCheckBox, "appendCheckBox");
            this.appendCheckBox.Name = "appendCheckBox";
            this.toolTip1.SetToolTip(this.appendCheckBox, resources.GetString("appendCheckBox.ToolTip"));
            this.appendCheckBox.UseVisualStyleBackColor = true;
            // 
            // customTextBox
            // 
            resources.ApplyResources(this.customTextBox, "customTextBox");
            this.customTextBox.Name = "customTextBox";
            this.toolTip1.SetToolTip(this.customTextBox, resources.GetString("customTextBox.ToolTip"));
            // 
            // groupBox2
            // 
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Controls.Add(this.append2CheckBox);
            this.groupBox2.Controls.Add(this.searchedPattern2Box);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.replacedPattern2Box);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.replacedTag2List);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.searchedTag2List);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBox2, resources.GetString("groupBox2.ToolTip"));
            // 
            // append2CheckBox
            // 
            resources.ApplyResources(this.append2CheckBox, "append2CheckBox");
            this.append2CheckBox.Name = "append2CheckBox";
            this.toolTip1.SetToolTip(this.append2CheckBox, resources.GetString("append2CheckBox.ToolTip"));
            this.append2CheckBox.UseVisualStyleBackColor = true;
            // 
            // searchedPattern2Box
            // 
            resources.ApplyResources(this.searchedPattern2Box, "searchedPattern2Box");
            this.searchedPattern2Box.Name = "searchedPattern2Box";
            this.toolTip1.SetToolTip(this.searchedPattern2Box, resources.GetString("searchedPattern2Box.ToolTip"));
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            this.toolTip1.SetToolTip(this.label7, resources.GetString("label7.ToolTip"));
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            this.toolTip1.SetToolTip(this.label8, resources.GetString("label8.ToolTip"));
            // 
            // replacedPattern2Box
            // 
            resources.ApplyResources(this.replacedPattern2Box, "replacedPattern2Box");
            this.replacedPattern2Box.Name = "replacedPattern2Box";
            this.toolTip1.SetToolTip(this.replacedPattern2Box, resources.GetString("replacedPattern2Box.ToolTip"));
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            this.toolTip1.SetToolTip(this.label9, resources.GetString("label9.ToolTip"));
            // 
            // replacedTag2List
            // 
            resources.ApplyResources(this.replacedTag2List, "replacedTag2List");
            this.replacedTag2List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.replacedTag2List.DropDownWidth = 250;
            this.replacedTag2List.FormattingEnabled = true;
            this.replacedTag2List.Name = "replacedTag2List";
            this.toolTip1.SetToolTip(this.replacedTag2List, resources.GetString("replacedTag2List.ToolTip"));
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            this.toolTip1.SetToolTip(this.label10, resources.GetString("label10.ToolTip"));
            // 
            // searchedTag2List
            // 
            resources.ApplyResources(this.searchedTag2List, "searchedTag2List");
            this.searchedTag2List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchedTag2List.DropDownWidth = 250;
            this.searchedTag2List.FormattingEnabled = true;
            this.searchedTag2List.Name = "searchedTag2List";
            this.toolTip1.SetToolTip(this.searchedTag2List, resources.GetString("searchedTag2List.ToolTip"));
            // 
            // groupBox3
            // 
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Controls.Add(this.append3CheckBox);
            this.groupBox3.Controls.Add(this.searchedPattern3Box);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.replacedPattern3Box);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.replacedTag3List);
            this.groupBox3.Controls.Add(this.searchedTag3List);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBox3, resources.GetString("groupBox3.ToolTip"));
            // 
            // append3CheckBox
            // 
            resources.ApplyResources(this.append3CheckBox, "append3CheckBox");
            this.append3CheckBox.Name = "append3CheckBox";
            this.toolTip1.SetToolTip(this.append3CheckBox, resources.GetString("append3CheckBox.ToolTip"));
            this.append3CheckBox.UseVisualStyleBackColor = true;
            // 
            // searchedPattern3Box
            // 
            resources.ApplyResources(this.searchedPattern3Box, "searchedPattern3Box");
            this.searchedPattern3Box.Name = "searchedPattern3Box";
            this.toolTip1.SetToolTip(this.searchedPattern3Box, resources.GetString("searchedPattern3Box.ToolTip"));
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            this.toolTip1.SetToolTip(this.label11, resources.GetString("label11.ToolTip"));
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            this.toolTip1.SetToolTip(this.label12, resources.GetString("label12.ToolTip"));
            // 
            // replacedPattern3Box
            // 
            resources.ApplyResources(this.replacedPattern3Box, "replacedPattern3Box");
            this.replacedPattern3Box.Name = "replacedPattern3Box";
            this.toolTip1.SetToolTip(this.replacedPattern3Box, resources.GetString("replacedPattern3Box.ToolTip"));
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            this.toolTip1.SetToolTip(this.label14, resources.GetString("label14.ToolTip"));
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            this.toolTip1.SetToolTip(this.label13, resources.GetString("label13.ToolTip"));
            // 
            // replacedTag3List
            // 
            resources.ApplyResources(this.replacedTag3List, "replacedTag3List");
            this.replacedTag3List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.replacedTag3List.DropDownWidth = 250;
            this.replacedTag3List.FormattingEnabled = true;
            this.replacedTag3List.Name = "replacedTag3List";
            this.toolTip1.SetToolTip(this.replacedTag3List, resources.GetString("replacedTag3List.ToolTip"));
            // 
            // searchedTag3List
            // 
            resources.ApplyResources(this.searchedTag3List, "searchedTag3List");
            this.searchedTag3List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchedTag3List.DropDownWidth = 250;
            this.searchedTag3List.FormattingEnabled = true;
            this.searchedTag3List.Name = "searchedTag3List";
            this.toolTip1.SetToolTip(this.searchedTag3List, resources.GetString("searchedTag3List.ToolTip"));
            // 
            // languages
            // 
            resources.ApplyResources(this.languages, "languages");
            this.languages.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.languages.FormattingEnabled = true;
            this.languages.Name = "languages";
            this.toolTip1.SetToolTip(this.languages, resources.GetString("languages.ToolTip"));
            this.languages.SelectedIndexChanged += new System.EventHandler(this.languages_SelectedIndexChanged);
            // 
            // guidBox
            // 
            resources.ApplyResources(this.guidBox, "guidBox");
            this.guidBox.Name = "guidBox";
            this.guidBox.ReadOnly = true;
            this.toolTip1.SetToolTip(this.guidBox, resources.GetString("guidBox.ToolTip"));
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            this.toolTip1.SetToolTip(this.label15, resources.GetString("label15.ToolTip"));
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            this.toolTip1.SetToolTip(this.label16, resources.GetString("label16.ToolTip"));
            // 
            // modifiedBox
            // 
            resources.ApplyResources(this.modifiedBox, "modifiedBox");
            this.modifiedBox.Name = "modifiedBox";
            this.modifiedBox.ReadOnly = true;
            this.toolTip1.SetToolTip(this.modifiedBox, resources.GetString("modifiedBox.ToolTip"));
            // 
            // modifiedByUserCheckBox
            // 
            resources.ApplyResources(this.modifiedByUserCheckBox, "modifiedByUserCheckBox");
            this.modifiedByUserCheckBox.Name = "modifiedByUserCheckBox";
            this.toolTip1.SetToolTip(this.modifiedByUserCheckBox, resources.GetString("modifiedByUserCheckBox.ToolTip"));
            this.modifiedByUserCheckBox.UseVisualStyleBackColor = true;
            // 
            // parameterTagTypeList
            // 
            resources.ApplyResources(this.parameterTagTypeList, "parameterTagTypeList");
            this.parameterTagTypeList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parameterTagTypeList.FormattingEnabled = true;
            this.parameterTagTypeList.Items.AddRange(new object[] {
            resources.GetString("parameterTagTypeList.Items"),
            resources.GetString("parameterTagTypeList.Items1"),
            resources.GetString("parameterTagTypeList.Items2")});
            this.parameterTagTypeList.Name = "parameterTagTypeList";
            this.toolTip1.SetToolTip(this.parameterTagTypeList, resources.GetString("parameterTagTypeList.ToolTip"));
            this.parameterTagTypeList.SelectedIndexChanged += new System.EventHandler(this.parameterTagTypeList_SelectedIndexChanged);
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            this.toolTip1.SetToolTip(this.label17, resources.GetString("label17.ToolTip"));
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            this.toolTip1.SetToolTip(this.label18, resources.GetString("label18.ToolTip"));
            // 
            // parameterTag2TypeList
            // 
            resources.ApplyResources(this.parameterTag2TypeList, "parameterTag2TypeList");
            this.parameterTag2TypeList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parameterTag2TypeList.FormattingEnabled = true;
            this.parameterTag2TypeList.Items.AddRange(new object[] {
            resources.GetString("parameterTag2TypeList.Items"),
            resources.GetString("parameterTag2TypeList.Items1"),
            resources.GetString("parameterTag2TypeList.Items2")});
            this.parameterTag2TypeList.Name = "parameterTag2TypeList";
            this.toolTip1.SetToolTip(this.parameterTag2TypeList, resources.GetString("parameterTag2TypeList.ToolTip"));
            this.parameterTag2TypeList.SelectedIndexChanged += new System.EventHandler(this.parameterTag2TypeList_SelectedIndexChanged);
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            this.toolTip1.SetToolTip(this.label19, resources.GetString("label19.ToolTip"));
            // 
            // parameterTag3TypeList
            // 
            resources.ApplyResources(this.parameterTag3TypeList, "parameterTag3TypeList");
            this.parameterTag3TypeList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parameterTag3TypeList.FormattingEnabled = true;
            this.parameterTag3TypeList.Items.AddRange(new object[] {
            resources.GetString("parameterTag3TypeList.Items"),
            resources.GetString("parameterTag3TypeList.Items1"),
            resources.GetString("parameterTag3TypeList.Items2")});
            this.parameterTag3TypeList.Name = "parameterTag3TypeList";
            this.toolTip1.SetToolTip(this.parameterTag3TypeList, resources.GetString("parameterTag3TypeList.ToolTip"));
            this.parameterTag3TypeList.SelectedIndexChanged += new System.EventHandler(this.parameterTag3TypeList_SelectedIndexChanged);
            // 
            // customTextCheckBox
            // 
            resources.ApplyResources(this.customTextCheckBox, "customTextCheckBox");
            this.customTextCheckBox.Name = "customTextCheckBox";
            this.toolTip1.SetToolTip(this.customTextCheckBox, resources.GetString("customTextCheckBox.ToolTip"));
            this.customTextCheckBox.UseVisualStyleBackColor = true;
            this.customTextCheckBox.CheckedChanged += new System.EventHandler(this.customTextChecked_CheckedChanged);
            // 
            // toolTip1
            // 
            this.toolTip1.AutoPopDelay = 10000;
            this.toolTip1.InitialDelay = 1500;
            this.toolTip1.ReshowDelay = 100;
            // 
            // customText2CheckBox
            // 
            resources.ApplyResources(this.customText2CheckBox, "customText2CheckBox");
            this.customText2CheckBox.Name = "customText2CheckBox";
            this.toolTip1.SetToolTip(this.customText2CheckBox, resources.GetString("customText2CheckBox.ToolTip"));
            this.customText2CheckBox.UseVisualStyleBackColor = true;
            this.customText2CheckBox.CheckedChanged += new System.EventHandler(this.customText2CheckBox_CheckedChanged);
            // 
            // customText2Box
            // 
            resources.ApplyResources(this.customText2Box, "customText2Box");
            this.customText2Box.Name = "customText2Box";
            this.toolTip1.SetToolTip(this.customText2Box, resources.GetString("customText2Box.ToolTip"));
            // 
            // customText4CheckBox
            // 
            resources.ApplyResources(this.customText4CheckBox, "customText4CheckBox");
            this.customText4CheckBox.Name = "customText4CheckBox";
            this.toolTip1.SetToolTip(this.customText4CheckBox, resources.GetString("customText4CheckBox.ToolTip"));
            this.customText4CheckBox.UseVisualStyleBackColor = true;
            this.customText4CheckBox.CheckedChanged += new System.EventHandler(this.customText4CheckBox_CheckedChanged);
            // 
            // customText4Box
            // 
            resources.ApplyResources(this.customText4Box, "customText4Box");
            this.customText4Box.Name = "customText4Box";
            this.toolTip1.SetToolTip(this.customText4Box, resources.GetString("customText4Box.ToolTip"));
            // 
            // customText3CheckBox
            // 
            resources.ApplyResources(this.customText3CheckBox, "customText3CheckBox");
            this.customText3CheckBox.Name = "customText3CheckBox";
            this.toolTip1.SetToolTip(this.customText3CheckBox, resources.GetString("customText3CheckBox.ToolTip"));
            this.customText3CheckBox.UseVisualStyleBackColor = true;
            this.customText3CheckBox.CheckedChanged += new System.EventHandler(this.customText3CheckBox_CheckedChanged);
            // 
            // customText3Box
            // 
            resources.ApplyResources(this.customText3Box, "customText3Box");
            this.customText3Box.Name = "customText3Box";
            this.toolTip1.SetToolTip(this.customText3Box, resources.GetString("customText3Box.ToolTip"));
            // 
            // append4CheckBox
            // 
            resources.ApplyResources(this.append4CheckBox, "append4CheckBox");
            this.append4CheckBox.Name = "append4CheckBox";
            this.toolTip1.SetToolTip(this.append4CheckBox, resources.GetString("append4CheckBox.ToolTip"));
            this.append4CheckBox.UseVisualStyleBackColor = true;
            // 
            // append5CheckBox
            // 
            resources.ApplyResources(this.append5CheckBox, "append5CheckBox");
            this.append5CheckBox.Name = "append5CheckBox";
            this.toolTip1.SetToolTip(this.append5CheckBox, resources.GetString("append5CheckBox.ToolTip"));
            this.append5CheckBox.UseVisualStyleBackColor = true;
            // 
            // parameterTag3List
            // 
            resources.ApplyResources(this.parameterTag3List, "parameterTag3List");
            this.parameterTag3List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parameterTag3List.DropDownWidth = 250;
            this.parameterTag3List.FormattingEnabled = true;
            this.parameterTag3List.Name = "parameterTag3List";
            this.toolTip1.SetToolTip(this.parameterTag3List, resources.GetString("parameterTag3List.ToolTip"));
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            this.toolTip1.SetToolTip(this.label21, resources.GetString("label21.ToolTip"));
            // 
            // parameterTag2List
            // 
            resources.ApplyResources(this.parameterTag2List, "parameterTag2List");
            this.parameterTag2List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parameterTag2List.DropDownWidth = 250;
            this.parameterTag2List.FormattingEnabled = true;
            this.parameterTag2List.Name = "parameterTag2List";
            this.toolTip1.SetToolTip(this.parameterTag2List, resources.GetString("parameterTag2List.ToolTip"));
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.Name = "label22";
            this.toolTip1.SetToolTip(this.label22, resources.GetString("label22.ToolTip"));
            // 
            // parameterTagList
            // 
            resources.ApplyResources(this.parameterTagList, "parameterTagList");
            this.parameterTagList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parameterTagList.DropDownWidth = 250;
            this.parameterTagList.FormattingEnabled = true;
            this.parameterTagList.Name = "parameterTagList";
            this.toolTip1.SetToolTip(this.parameterTagList, resources.GetString("parameterTagList.ToolTip"));
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.Name = "label23";
            this.toolTip1.SetToolTip(this.label23, resources.GetString("label23.ToolTip"));
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            this.toolTip1.SetToolTip(this.label20, resources.GetString("label20.ToolTip"));
            // 
            // parameterTag6List
            // 
            resources.ApplyResources(this.parameterTag6List, "parameterTag6List");
            this.parameterTag6List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parameterTag6List.DropDownWidth = 250;
            this.parameterTag6List.FormattingEnabled = true;
            this.parameterTag6List.Name = "parameterTag6List";
            this.toolTip1.SetToolTip(this.parameterTag6List, resources.GetString("parameterTag6List.ToolTip"));
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.Name = "label24";
            this.toolTip1.SetToolTip(this.label24, resources.GetString("label24.ToolTip"));
            // 
            // parameterTag5List
            // 
            resources.ApplyResources(this.parameterTag5List, "parameterTag5List");
            this.parameterTag5List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parameterTag5List.DropDownWidth = 250;
            this.parameterTag5List.FormattingEnabled = true;
            this.parameterTag5List.Name = "parameterTag5List";
            this.toolTip1.SetToolTip(this.parameterTag5List, resources.GetString("parameterTag5List.ToolTip"));
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.Name = "label25";
            this.toolTip1.SetToolTip(this.label25, resources.GetString("label25.ToolTip"));
            // 
            // parameterTag4List
            // 
            resources.ApplyResources(this.parameterTag4List, "parameterTag4List");
            this.parameterTag4List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parameterTag4List.DropDownWidth = 250;
            this.parameterTag4List.FormattingEnabled = true;
            this.parameterTag4List.Name = "parameterTag4List";
            this.toolTip1.SetToolTip(this.parameterTag4List, resources.GetString("parameterTag4List.ToolTip"));
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.Name = "label26";
            this.toolTip1.SetToolTip(this.label26, resources.GetString("label26.ToolTip"));
            // 
            // parameterTag6TypeList
            // 
            resources.ApplyResources(this.parameterTag6TypeList, "parameterTag6TypeList");
            this.parameterTag6TypeList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parameterTag6TypeList.FormattingEnabled = true;
            this.parameterTag6TypeList.Items.AddRange(new object[] {
            resources.GetString("parameterTag6TypeList.Items"),
            resources.GetString("parameterTag6TypeList.Items1"),
            resources.GetString("parameterTag6TypeList.Items2")});
            this.parameterTag6TypeList.Name = "parameterTag6TypeList";
            this.toolTip1.SetToolTip(this.parameterTag6TypeList, resources.GetString("parameterTag6TypeList.ToolTip"));
            this.parameterTag6TypeList.SelectedIndexChanged += new System.EventHandler(this.parameterTag6TypeList_SelectedIndexChanged);
            // 
            // label27
            // 
            resources.ApplyResources(this.label27, "label27");
            this.label27.Name = "label27";
            this.toolTip1.SetToolTip(this.label27, resources.GetString("label27.ToolTip"));
            // 
            // parameterTag5TypeList
            // 
            resources.ApplyResources(this.parameterTag5TypeList, "parameterTag5TypeList");
            this.parameterTag5TypeList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parameterTag5TypeList.FormattingEnabled = true;
            this.parameterTag5TypeList.Items.AddRange(new object[] {
            resources.GetString("parameterTag5TypeList.Items"),
            resources.GetString("parameterTag5TypeList.Items1"),
            resources.GetString("parameterTag5TypeList.Items2")});
            this.parameterTag5TypeList.Name = "parameterTag5TypeList";
            this.toolTip1.SetToolTip(this.parameterTag5TypeList, resources.GetString("parameterTag5TypeList.ToolTip"));
            this.parameterTag5TypeList.SelectedIndexChanged += new System.EventHandler(this.parameterTag5TypeList_SelectedIndexChanged);
            // 
            // label28
            // 
            resources.ApplyResources(this.label28, "label28");
            this.label28.Name = "label28";
            this.toolTip1.SetToolTip(this.label28, resources.GetString("label28.ToolTip"));
            // 
            // parameterTag4TypeList
            // 
            resources.ApplyResources(this.parameterTag4TypeList, "parameterTag4TypeList");
            this.parameterTag4TypeList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parameterTag4TypeList.FormattingEnabled = true;
            this.parameterTag4TypeList.Items.AddRange(new object[] {
            resources.GetString("parameterTag4TypeList.Items"),
            resources.GetString("parameterTag4TypeList.Items1"),
            resources.GetString("parameterTag4TypeList.Items2")});
            this.parameterTag4TypeList.Name = "parameterTag4TypeList";
            this.toolTip1.SetToolTip(this.parameterTag4TypeList, resources.GetString("parameterTag4TypeList.ToolTip"));
            this.parameterTag4TypeList.SelectedIndexChanged += new System.EventHandler(this.parameterTag4TypeList_SelectedIndexChanged);
            // 
            // groupBox4
            // 
            resources.ApplyResources(this.groupBox4, "groupBox4");
            this.groupBox4.Controls.Add(this.append4CheckBox);
            this.groupBox4.Controls.Add(this.searchedPattern4Box);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.replacedPattern4Box);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.replacedTag4List);
            this.groupBox4.Controls.Add(this.searchedTag4List);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBox4, resources.GetString("groupBox4.ToolTip"));
            // 
            // searchedPattern4Box
            // 
            resources.ApplyResources(this.searchedPattern4Box, "searchedPattern4Box");
            this.searchedPattern4Box.Name = "searchedPattern4Box";
            this.toolTip1.SetToolTip(this.searchedPattern4Box, resources.GetString("searchedPattern4Box.ToolTip"));
            // 
            // label29
            // 
            resources.ApplyResources(this.label29, "label29");
            this.label29.Name = "label29";
            this.toolTip1.SetToolTip(this.label29, resources.GetString("label29.ToolTip"));
            // 
            // label30
            // 
            resources.ApplyResources(this.label30, "label30");
            this.label30.Name = "label30";
            this.toolTip1.SetToolTip(this.label30, resources.GetString("label30.ToolTip"));
            // 
            // replacedPattern4Box
            // 
            resources.ApplyResources(this.replacedPattern4Box, "replacedPattern4Box");
            this.replacedPattern4Box.Name = "replacedPattern4Box";
            this.toolTip1.SetToolTip(this.replacedPattern4Box, resources.GetString("replacedPattern4Box.ToolTip"));
            // 
            // label31
            // 
            resources.ApplyResources(this.label31, "label31");
            this.label31.Name = "label31";
            this.toolTip1.SetToolTip(this.label31, resources.GetString("label31.ToolTip"));
            // 
            // label32
            // 
            resources.ApplyResources(this.label32, "label32");
            this.label32.Name = "label32";
            this.toolTip1.SetToolTip(this.label32, resources.GetString("label32.ToolTip"));
            // 
            // replacedTag4List
            // 
            resources.ApplyResources(this.replacedTag4List, "replacedTag4List");
            this.replacedTag4List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.replacedTag4List.DropDownWidth = 250;
            this.replacedTag4List.FormattingEnabled = true;
            this.replacedTag4List.Name = "replacedTag4List";
            this.toolTip1.SetToolTip(this.replacedTag4List, resources.GetString("replacedTag4List.ToolTip"));
            // 
            // searchedTag4List
            // 
            resources.ApplyResources(this.searchedTag4List, "searchedTag4List");
            this.searchedTag4List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchedTag4List.DropDownWidth = 250;
            this.searchedTag4List.FormattingEnabled = true;
            this.searchedTag4List.Name = "searchedTag4List";
            this.toolTip1.SetToolTip(this.searchedTag4List, resources.GetString("searchedTag4List.ToolTip"));
            // 
            // groupBox5
            // 
            resources.ApplyResources(this.groupBox5, "groupBox5");
            this.groupBox5.Controls.Add(this.append5CheckBox);
            this.groupBox5.Controls.Add(this.searchedPattern5Box);
            this.groupBox5.Controls.Add(this.label33);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.replacedPattern5Box);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.replacedTag5List);
            this.groupBox5.Controls.Add(this.searchedTag5List);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.TabStop = false;
            this.toolTip1.SetToolTip(this.groupBox5, resources.GetString("groupBox5.ToolTip"));
            // 
            // searchedPattern5Box
            // 
            resources.ApplyResources(this.searchedPattern5Box, "searchedPattern5Box");
            this.searchedPattern5Box.Name = "searchedPattern5Box";
            this.toolTip1.SetToolTip(this.searchedPattern5Box, resources.GetString("searchedPattern5Box.ToolTip"));
            // 
            // label33
            // 
            resources.ApplyResources(this.label33, "label33");
            this.label33.Name = "label33";
            this.toolTip1.SetToolTip(this.label33, resources.GetString("label33.ToolTip"));
            // 
            // label34
            // 
            resources.ApplyResources(this.label34, "label34");
            this.label34.Name = "label34";
            this.toolTip1.SetToolTip(this.label34, resources.GetString("label34.ToolTip"));
            // 
            // replacedPattern5Box
            // 
            resources.ApplyResources(this.replacedPattern5Box, "replacedPattern5Box");
            this.replacedPattern5Box.Name = "replacedPattern5Box";
            this.toolTip1.SetToolTip(this.replacedPattern5Box, resources.GetString("replacedPattern5Box.ToolTip"));
            // 
            // label35
            // 
            resources.ApplyResources(this.label35, "label35");
            this.label35.Name = "label35";
            this.toolTip1.SetToolTip(this.label35, resources.GetString("label35.ToolTip"));
            // 
            // label36
            // 
            resources.ApplyResources(this.label36, "label36");
            this.label36.Name = "label36";
            this.toolTip1.SetToolTip(this.label36, resources.GetString("label36.ToolTip"));
            // 
            // replacedTag5List
            // 
            resources.ApplyResources(this.replacedTag5List, "replacedTag5List");
            this.replacedTag5List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.replacedTag5List.DropDownWidth = 250;
            this.replacedTag5List.FormattingEnabled = true;
            this.replacedTag5List.Name = "replacedTag5List";
            this.toolTip1.SetToolTip(this.replacedTag5List, resources.GetString("replacedTag5List.ToolTip"));
            // 
            // searchedTag5List
            // 
            resources.ApplyResources(this.searchedTag5List, "searchedTag5List");
            this.searchedTag5List.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchedTag5List.DropDownWidth = 250;
            this.searchedTag5List.FormattingEnabled = true;
            this.searchedTag5List.Name = "searchedTag5List";
            this.toolTip1.SetToolTip(this.searchedTag5List, resources.GetString("searchedTag5List.ToolTip"));
            // 
            // ASRPresetEditor
            // 
            this.AcceptButton = this.buttonApply;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonCancel;
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.customText4CheckBox);
            this.Controls.Add(this.customText4Box);
            this.Controls.Add(this.customText3CheckBox);
            this.Controls.Add(this.customText3Box);
            this.Controls.Add(this.customText2CheckBox);
            this.Controls.Add(this.customText2Box);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.parameterTag6List);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.parameterTag5List);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.parameterTag4List);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.parameterTag6TypeList);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.parameterTag5TypeList);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.parameterTag4TypeList);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.parameterTag3List);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.parameterTag2List);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.parameterTagList);
            this.Controls.Add(this.customTextCheckBox);
            this.Controls.Add(this.customTextBox);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.parameterTag3TypeList);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.parameterTag2TypeList);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.parameterTagTypeList);
            this.Controls.Add(this.modifiedByUserCheckBox);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.modifiedBox);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.guidBox);
            this.Controls.Add(this.languages);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.ignoreCaseCheckBox);
            this.Controls.Add(this.buttonApply);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.descriptionBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ASRPresetEditor";
            this.toolTip1.SetToolTip(this, resources.GetString("$this.ToolTip"));
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox descriptionBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox searchedPatternBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox searchedTagList;
        private System.Windows.Forms.ComboBox replacedTagList;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox replacedPatternBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonApply;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.CheckBox ignoreCaseCheckBox;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox searchedPattern2Box;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox replacedPattern2Box;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox replacedTag2List;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox searchedTag2List;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox searchedPattern3Box;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox replacedPattern3Box;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox replacedTag3List;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox searchedTag3List;
        private System.Windows.Forms.ComboBox languages;
        private System.Windows.Forms.TextBox guidBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox modifiedBox;
        private System.Windows.Forms.CheckBox modifiedByUserCheckBox;
        private System.Windows.Forms.ComboBox parameterTagTypeList;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox parameterTag2TypeList;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox parameterTag3TypeList;
        private System.Windows.Forms.TextBox customTextBox;
        private System.Windows.Forms.CheckBox customTextCheckBox;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ComboBox parameterTag3List;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox parameterTag2List;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox parameterTagList;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox parameterTag6List;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox parameterTag5List;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox parameterTag4List;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox parameterTag6TypeList;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox parameterTag5TypeList;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox parameterTag4TypeList;
        private System.Windows.Forms.CheckBox customText2CheckBox;
        private System.Windows.Forms.TextBox customText2Box;
        private System.Windows.Forms.CheckBox customText4CheckBox;
        private System.Windows.Forms.TextBox customText4Box;
        private System.Windows.Forms.CheckBox customText3CheckBox;
        private System.Windows.Forms.TextBox customText3Box;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox searchedPattern4Box;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox replacedPattern4Box;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox replacedTag4List;
        private System.Windows.Forms.ComboBox searchedTag4List;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox searchedPattern5Box;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox replacedPattern5Box;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox replacedTag5List;
        private System.Windows.Forms.ComboBox searchedTag5List;
        private System.Windows.Forms.CheckBox appendCheckBox;
        private System.Windows.Forms.CheckBox append2CheckBox;
        private System.Windows.Forms.CheckBox append3CheckBox;
        private System.Windows.Forms.CheckBox append4CheckBox;
        private System.Windows.Forms.CheckBox append5CheckBox;
    }
}