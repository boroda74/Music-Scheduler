﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MusicBeePlugin
{
    public partial class SwapTagsPlugin : ToolsPluginTemplate
    {
        private Plugin.MetaDataType sourceTagId;
        private Plugin.MetaDataType destinationTagId;
        private string[] files = new string[0];

        public SwapTagsPlugin()
        {
            InitializeComponent();
        }

        public SwapTagsPlugin(Plugin tagToolsPluginParam)
        {
            InitializeComponent();

            tagToolsPlugin = tagToolsPluginParam;

            initializeForm();
        }

        protected new void initializeForm()
        {
            base.initializeForm();

            tagToolsPlugin.fillList(sourceTagList.Items);
            sourceTagList.Text = Plugin.SavedSettings.swapTagsSourceTagName;

            tagToolsPlugin.fillList(destinationTagList.Items);
            destinationTagList.Text = Plugin.SavedSettings.swapTagsDestinationTagName;

            smartOperationCheckBox.Checked = Plugin.SavedSettings.smartOperation;
        }

        private bool prepareBackgroundTask()
        {
            if (backgroundTaskIsWorking())
                return true;

            sourceTagId = tagToolsPlugin.getTagId(sourceTagList.Text);
            destinationTagId = tagToolsPlugin.getTagId(destinationTagList.Text);

            if (mbApiInterface.Library_QueryFiles("domain=SelectedFiles"))
                files = mbApiInterface.Library_QueryGetAllFiles().Split(tagToolsPlugin.filesSeparators, StringSplitOptions.RemoveEmptyEntries);
            else
                files = new string[0];

            if (files.Length == 0)
            {
                MessageBox.Show(tagToolsPlugin.msgNoFilesSelected);
                return false;
            }
            else
            {
                return true;
            }
        }

        private void swapTags()
        {
            string currentFile;
            string sourceTagValue;
            string destinationTagValue;
            Plugin.SwappedTags swappedTags;

            for (int fileCounter = 0; fileCounter < files.Length; fileCounter++)
            {
                if (backgroundTaskIsCanceled)
                    return;

                currentFile = files[fileCounter];

                tagToolsPlugin.setSbText(tagToolsPlugin.swapTagsCommandSbText, false, fileCounter, files.Length, currentFile);

                sourceTagValue = tagToolsPlugin.getFileTag(currentFile, sourceTagId);
                destinationTagValue = tagToolsPlugin.getFileTag(currentFile, destinationTagId);

                swappedTags = tagToolsPlugin.swapTags(sourceTagValue, destinationTagValue, sourceTagId, destinationTagId, smartOperationCheckBox.Checked);

                if (sourceTagId != destinationTagId)
                    tagToolsPlugin.setFileTag(currentFile, destinationTagId, swappedTags.newDestinationTagValue);

                tagToolsPlugin.setFileTag(currentFile, sourceTagId, swappedTags.newSourceTagValue);
                tagToolsPlugin.commitTagsToFile(currentFile);
            }
        }

        private void saveSettings()
        {
            Plugin.SavedSettings.swapTagsSourceTagName = sourceTagList.Text;
            Plugin.SavedSettings.swapTagsDestinationTagName = destinationTagList.Text;
            Plugin.SavedSettings.smartOperation = smartOperationCheckBox.Checked;
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            if (sourceTagList.Text == destinationTagList.Text)
                if(!smartOperationCheckBox.Checked || !(tagToolsPlugin.getTagId(sourceTagList.Text) == Plugin.ArtistArtistsId || tagToolsPlugin.getTagId(sourceTagList.Text) == Plugin.ComposerComposersId))
                {
                    MessageBox.Show(tagToolsPlugin.msgSwapTagsSourceAndDestinationTagsAreTheSame);
                    return;
                }

            saveSettings();
            if (prepareBackgroundTask())
                switchOperation(swapTags, (Button)sender, tagToolsPlugin.emptyButton, buttonCancel);
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        public override void enableQueryingButtons()
        {
            dirtyErrorProvider.SetError(buttonOK, " ");
            dirtyErrorProvider.SetError(buttonOK, String.Empty);
        }

        public override void enableQueryingOrUpdatingButtons()
        {
            buttonOK.Enabled = true;
        }

        public override void disableQueryingOrUpdatingButtons()
        {
            buttonOK.Enabled = false;
        }
    }
}
