﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MusicBeePlugin
{
    public partial class SettingsPlugin : ToolsPluginTemplate
    {
        protected Plugin.PluginInfo about;

        protected void setMenuPlacementRadioButtons(int pos)
        {
            switch (pos)
            {
                case 1:
                    menuPlacement1RadioButton.Checked = true;
                    break;
                case 2:
                    menuPlacement2RadioButton.Checked = true;
                    break;
                default:
                    menuPlacement3RadioButton.Checked = true;
                    break;
            }
        }

        protected int getMenuPlacementRadioButtons()
        {
            if (menuPlacement1RadioButton.Checked) return 1;
            else if (menuPlacement2RadioButton.Checked) return 2;
            else return 3;
        }

        protected void setCloseShowWindowsRadioButtons(int pos)
        {
            switch (pos)
            {
                case 1:
                    closeHiddenCommandWindowsRadioButton.Checked = true;
                    break;
                default:
                    showHiddenCommandWindowsRadioButton.Checked = true;
                    break;
            }
        }

        protected int getCloseShowWindowsRadioButtons()
        {
            if (closeHiddenCommandWindowsRadioButton.Checked) return 1;
            else return 2;
        }

        public SettingsPlugin()
        {
            InitializeComponent();
        }

        public SettingsPlugin(Plugin tagToolsPluginParam, Plugin.PluginInfo aboutParam)
        {
            InitializeComponent();

            tagToolsPlugin = tagToolsPluginParam;
            about = aboutParam;

            initializeForm();
        }

        protected new void initializeForm()
        {
            base.initializeForm();

            versionLabel.Text += about.VersionMajor + "." + about.VersionMinor + "." + about.Revision;

            setMenuPlacementRadioButtons(Plugin.SavedSettings.menuPlacement);

            showCopyTagCheckBox.Checked = !Plugin.SavedSettings.dontShowCopyTag;
            showSwapTagsCheckBox.Checked = !Plugin.SavedSettings.dontShowSwapTags;
            showChangeCaseCheckBox.Checked = !Plugin.SavedSettings.dontShowChangeCase;
            showRencodeTagCheckBox.Checked = !Plugin.SavedSettings.dontShowRencodeTag;
            showExportTagsCheckBox.Checked = !Plugin.SavedSettings.dontShowExportTags;
            showAutorateCheckBox.Checked = !Plugin.SavedSettings.dontShowAutorate;
            showASRCheckBox.Checked = !Plugin.SavedSettings.dontShowASR;
            showCARCheckBox.Checked = !Plugin.SavedSettings.dontShowCAR;
            showShowHiddenWindowsCheckBox.Checked = !Plugin.SavedSettings.dontShowShowHiddenWindows;

            useSkinColorsCheckBox.Checked = Plugin.SavedSettings.useSkinColors;
            setCloseShowWindowsRadioButtons(Plugin.SavedSettings.closeShowHiddenWindows);

            playCompletedSoundCheckBox.Checked = !Plugin.SavedSettings.dontPlayCompletedSound;
            playStartedSoundCheckBox.Checked = Plugin.SavedSettings.playStartedSound;
            playStoppedSoundCheckBox.Checked = Plugin.SavedSettings.playCanceledSound;

            unitKBox.Text = Plugin.SavedSettings.unitK;
            unitMBox.Text = Plugin.SavedSettings.unitM;
            unitGBox.Text = Plugin.SavedSettings.unitG;
        }

        private void saveSettings()
        {
            Plugin.SavedSettings.menuPlacement = getMenuPlacementRadioButtons();

            Plugin.SavedSettings.dontShowCopyTag = !showCopyTagCheckBox.Checked;
            Plugin.SavedSettings.dontShowSwapTags = !showSwapTagsCheckBox.Checked;
            Plugin.SavedSettings.dontShowChangeCase = !showChangeCaseCheckBox.Checked;
            Plugin.SavedSettings.dontShowRencodeTag = !showRencodeTagCheckBox.Checked;
            Plugin.SavedSettings.dontShowExportTags = !showExportTagsCheckBox.Checked;
            Plugin.SavedSettings.dontShowAutorate = !showAutorateCheckBox.Checked;
            Plugin.SavedSettings.dontShowASR = !showASRCheckBox.Checked;
            Plugin.SavedSettings.dontShowCAR = !showCARCheckBox.Checked;
            Plugin.SavedSettings.dontShowShowHiddenWindows = !showShowHiddenWindowsCheckBox.Checked;

            Plugin.SavedSettings.useSkinColors = useSkinColorsCheckBox.Checked;
            Plugin.SavedSettings.closeShowHiddenWindows = getCloseShowWindowsRadioButtons();

            Plugin.SavedSettings.dontPlayCompletedSound = !playCompletedSoundCheckBox.Checked;
            Plugin.SavedSettings.playStartedSound = playStartedSoundCheckBox.Checked;
            Plugin.SavedSettings.playCanceledSound = playStoppedSoundCheckBox.Checked;

            Plugin.SavedSettings.unitK = unitKBox.Text;
            Plugin.SavedSettings.unitM = unitMBox.Text;
            Plugin.SavedSettings.unitG = unitGBox.Text;
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            saveSettings();
            Close();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
