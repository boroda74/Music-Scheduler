﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace MusicBeePlugin
{
    public partial class MultiplePastingQuestion : PluginWindowTemplate
    {
        public int fileTagsLength = 0;
        public int filesLength = 0;
        public bool pasteAnyway = false;

        public MultiplePastingQuestion()
        {
            InitializeComponent();
        }

        public MultiplePastingQuestion(Plugin tagToolsPluginParam)
        {
            InitializeComponent();

            TagToolsPlugin = tagToolsPluginParam;

            initializeForm();
        }

        protected new void initializeForm()
        {
            base.initializeForm();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            pasteAnyway = true;
            Close();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
