﻿using System;
using System.Windows.Forms;
using System.Text;

namespace MusicBeePlugin
{
    public partial class Plugin
    {
        public void fillTagNames()
        {
            readonlyTagsNames = new string[28];

            readonlyTagsNames[0] = genreCategoryName;
            readonlyTagsNames[1] = lyricsName;
            readonlyTagsNames[2] = synchronisedLyricsName;
            readonlyTagsNames[3] = unsynchronisedLyricsName;
            readonlyTagsNames[4] = displayedAlbumArtsistName;
            readonlyTagsNames[5] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.HasLyrics);
            readonlyTagsNames[6] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual1);
            readonlyTagsNames[7] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual2);
            readonlyTagsNames[8] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual3);
            readonlyTagsNames[9] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual4);
            readonlyTagsNames[10] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual5);
            readonlyTagsNames[11] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual6);
            readonlyTagsNames[12] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual7);
            readonlyTagsNames[13] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual8);
            readonlyTagsNames[14] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual9);

            readonlyTagsNames[15] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual10);
            readonlyTagsNames[16] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual11);
            readonlyTagsNames[17] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual12);
            readonlyTagsNames[18] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual13);
            readonlyTagsNames[19] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual14);
            readonlyTagsNames[20] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual15);
            readonlyTagsNames[21] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual16);

            readonlyTagsNames[22] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genres);
            readonlyTagsNames[23] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Artists);
            readonlyTagsNames[24] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithArtistRole);
            readonlyTagsNames[25] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithPerformerRole);
            readonlyTagsNames[26] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithGuestRole);
            readonlyTagsNames[27] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithRemixerRole);
            

            //Tags
            bool wereErrors = false;
            Encoding unicode1 = Encoding.UTF8;
            System.IO.FileStream stream1 = System.IO.File.Open(System.IO.Path.Combine(mbApiInterface.Setting_GetPersistentStoragePath(), "TagTools.TagNamesErrorLog.txt"), System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None);
            System.IO.StreamWriter file1 = new System.IO.StreamWriter(stream1, unicode1);

            tagNamesIds.Clear();
            tagIdsNames.Clear();

            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackTitle) + " / " + Plugin.MetaDataType.TrackTitle);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackTitle), Plugin.MetaDataType.TrackTitle);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackTitle) + " / " + Plugin.MetaDataType.TrackTitle);
            }
            try
            {
                file1.WriteLine("Adding " + albumTagName + " / " + Plugin.MetaDataType.Album);
                tagNamesIds.Add(albumTagName, Plugin.MetaDataType.Album);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + albumTagName + " / " + Plugin.MetaDataType.Album);
            }
            try
            {
                file1.WriteLine("Adding " + displayedAlbumArtsistName + " / " + Plugin.MetaDataType.AlbumArtist);
                tagNamesIds.Add(displayedAlbumArtsistName, Plugin.MetaDataType.AlbumArtist);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + displayedAlbumArtsistName + " / " + Plugin.MetaDataType.AlbumArtist);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.AlbumArtist) + " / " + Plugin.MetaDataType.AlbumArtistRaw);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.AlbumArtist), Plugin.MetaDataType.AlbumArtistRaw);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.AlbumArtist) + " / " + Plugin.MetaDataType.AlbumArtistRaw);
            }
            try
            {
                file1.WriteLine("Adding " + displayedArtistName + " / " + Plugin.DisplayedArtistId);
                tagNamesIds.Add(displayedArtistName, Plugin.DisplayedArtistId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + displayedArtistName + " / " + Plugin.DisplayedArtistId);
            }
            try
            {
                file1.WriteLine("Adding " + artistArtistsName + " / " + Plugin.ArtistArtistsId);
                tagNamesIds.Add(artistArtistsName, Plugin.ArtistArtistsId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + artistArtistsName + " / " + Plugin.ArtistArtistsId);
            }
            try
            {
                file1.WriteLine("Adding " + artworkName + " / " + Plugin.MetaDataType.Artwork);
                tagNamesIds.Add(artworkName, Plugin.MetaDataType.Artwork);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + artworkName + " / " + Plugin.MetaDataType.Artwork);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.BeatsPerMin) + " / " + Plugin.MetaDataType.BeatsPerMin);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.BeatsPerMin), Plugin.MetaDataType.BeatsPerMin);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.BeatsPerMin) + " / " + Plugin.MetaDataType.BeatsPerMin);
            }
            try
            {
                file1.WriteLine("Adding " + displayedComposerName + " / " + Plugin.DisplayedComposerId);
                tagNamesIds.Add(displayedComposerName, Plugin.DisplayedComposerId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + displayedComposerName + " / " + Plugin.DisplayedComposerId);
            }
            try
            {
                file1.WriteLine("Adding " + composerComposersName + " / " + Plugin.ComposerComposersId);
                tagNamesIds.Add(composerComposersName, Plugin.ComposerComposersId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + composerComposersName + " / " + Plugin.ComposerComposersId);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Comment) + " / " + Plugin.MetaDataType.Comment);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Comment), Plugin.MetaDataType.Comment);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Comment) + " / " + Plugin.MetaDataType.Comment);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Conductor) + " / " + Plugin.MetaDataType.Conductor);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Conductor), Plugin.MetaDataType.Conductor);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Conductor) + " / " + Plugin.MetaDataType.Conductor);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscNo) + " / " + Plugin.MetaDataType.DiscNo);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscNo), Plugin.MetaDataType.DiscNo);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscNo) + " / " + Plugin.MetaDataType.DiscNo);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscCount) + " / " + Plugin.MetaDataType.DiscCount);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscCount), Plugin.MetaDataType.DiscCount);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscCount) + " / " + Plugin.MetaDataType.DiscCount);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Encoder) + " / " + Plugin.MetaDataType.Encoder);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Encoder), Plugin.MetaDataType.Encoder);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Encoder) + " / " + Plugin.MetaDataType.Encoder);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genre) + " / " + Plugin.MetaDataType.Genre);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genre), Plugin.MetaDataType.Genre);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genre) + " / " + Plugin.MetaDataType.Genre);
            }
            try
            {
                file1.WriteLine("Adding " + genreCategoryName + " / " + Plugin.MetaDataType.GenreCategory);
                tagNamesIds.Add(genreCategoryName, Plugin.MetaDataType.GenreCategory);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + genreCategoryName + " / " + Plugin.MetaDataType.GenreCategory);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Grouping) + " / " + Plugin.MetaDataType.Grouping);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Grouping), Plugin.MetaDataType.Grouping);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Grouping) + " / " + Plugin.MetaDataType.Grouping);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Keywords) + " / " + Plugin.MetaDataType.Keywords);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Keywords), Plugin.MetaDataType.Keywords);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Keywords) + " / " + Plugin.MetaDataType.Keywords);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Lyricist) + " / " + Plugin.MetaDataType.Lyricist);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Lyricist), Plugin.MetaDataType.Lyricist);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Lyricist) + " / " + Plugin.MetaDataType.Lyricist);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Mood) + " / " + Plugin.MetaDataType.Mood);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Mood), Plugin.MetaDataType.Mood);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Mood) + " / " + Plugin.MetaDataType.Mood);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Occasion) + " / " + Plugin.MetaDataType.Occasion);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Occasion), Plugin.MetaDataType.Occasion);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Occasion) + " / " + Plugin.MetaDataType.Occasion);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Origin) + " / " + Plugin.MetaDataType.Origin);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Origin), Plugin.MetaDataType.Origin);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Origin) + " / " + Plugin.MetaDataType.Origin);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Publisher) + " / " + Plugin.MetaDataType.Publisher);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Publisher), Plugin.MetaDataType.Publisher);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Publisher) + " / " + Plugin.MetaDataType.Publisher);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Quality) + " / " + Plugin.MetaDataType.Quality);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Quality), Plugin.MetaDataType.Quality);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Quality) + " / " + Plugin.MetaDataType.Quality);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Rating) + " / " + Plugin.MetaDataType.Rating);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Rating), Plugin.MetaDataType.Rating);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Rating) + " / " + Plugin.MetaDataType.Rating);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingAlbum) + " / " + Plugin.MetaDataType.RatingAlbum);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingAlbum), Plugin.MetaDataType.RatingAlbum);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingAlbum) + " / " + Plugin.MetaDataType.RatingAlbum);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingLove) + " / " + Plugin.MetaDataType.RatingLove);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingLove), Plugin.MetaDataType.RatingLove);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingLove) + " / " + Plugin.MetaDataType.RatingLove);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Tempo) + " / " + Plugin.MetaDataType.Tempo);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Tempo), Plugin.MetaDataType.Tempo);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Tempo) + " / " + Plugin.MetaDataType.Tempo);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackNo) + " / " + Plugin.MetaDataType.TrackNo);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackNo), Plugin.MetaDataType.TrackNo);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackNo) + " / " + Plugin.MetaDataType.TrackNo);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackCount) + " / " + Plugin.MetaDataType.TrackCount);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackCount), Plugin.MetaDataType.TrackCount);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackCount) + " / " + Plugin.MetaDataType.TrackCount);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Year) + " / " + Plugin.MetaDataType.Year);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Year), Plugin.MetaDataType.Year);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Year) + " / " + Plugin.MetaDataType.Year);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.HasLyrics) + " / " + Plugin.MetaDataType.HasLyrics);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.HasLyrics), Plugin.MetaDataType.HasLyrics);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.HasLyrics) + " / " + Plugin.MetaDataType.HasLyrics);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual1) + " / " + Plugin.MetaDataType.Virtual1);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual1), Plugin.MetaDataType.Virtual1);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual1) + " / " + Plugin.MetaDataType.Virtual1);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual2) + " / " + Plugin.MetaDataType.Virtual2);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual2), Plugin.MetaDataType.Virtual2);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual2) + " / " + Plugin.MetaDataType.Virtual2);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual3) + " / " + Plugin.MetaDataType.Virtual3);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual3), Plugin.MetaDataType.Virtual3);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual3) + " / " + Plugin.MetaDataType.Virtual3);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual4) + " / " + Plugin.MetaDataType.Virtual4);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual4), Plugin.MetaDataType.Virtual4);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual4) + " / " + Plugin.MetaDataType.Virtual4);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual5) + " / " + Plugin.MetaDataType.Virtual5);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual5), Plugin.MetaDataType.Virtual5);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual5) + " / " + Plugin.MetaDataType.Virtual5);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual6) + " / " + Plugin.MetaDataType.Virtual6);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual6), Plugin.MetaDataType.Virtual6);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual6) + " / " + Plugin.MetaDataType.Virtual6);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual7) + " / " + Plugin.MetaDataType.Virtual7);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual7), Plugin.MetaDataType.Virtual7);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual7) + " / " + Plugin.MetaDataType.Virtual7);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual8) + " / " + Plugin.MetaDataType.Virtual8);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual8), Plugin.MetaDataType.Virtual8);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual8) + " / " + Plugin.MetaDataType.Virtual8);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual9) + " / " + Plugin.MetaDataType.Virtual9);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual9), Plugin.MetaDataType.Virtual9);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual9) + " / " + Plugin.MetaDataType.Virtual9);
            }

            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual10) + " / " + Plugin.MetaDataType.Virtual10);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual10), Plugin.MetaDataType.Virtual10);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual10) + " / " + Plugin.MetaDataType.Virtual10);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual11) + " / " + Plugin.MetaDataType.Virtual11);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual11), Plugin.MetaDataType.Virtual11);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual11) + " / " + Plugin.MetaDataType.Virtual11);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual12) + " / " + Plugin.MetaDataType.Virtual12);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual12), Plugin.MetaDataType.Virtual12);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual12) + " / " + Plugin.MetaDataType.Virtual12);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual13) + " / " + Plugin.MetaDataType.Virtual13);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual13), Plugin.MetaDataType.Virtual13);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual13) + " / " + Plugin.MetaDataType.Virtual13);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual14) + " / " + Plugin.MetaDataType.Virtual14);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual14), Plugin.MetaDataType.Virtual14);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual14) + " / " + Plugin.MetaDataType.Virtual14);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual15) + " / " + Plugin.MetaDataType.Virtual15);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual15), Plugin.MetaDataType.Virtual15);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual15) + " / " + Plugin.MetaDataType.Virtual15);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual16) + " / " + Plugin.MetaDataType.Virtual16);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual16), Plugin.MetaDataType.Virtual16);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual16) + " / " + Plugin.MetaDataType.Virtual16);
            }


            try
            {
                file1.WriteLine("Adding " + lyricsName + " / " + Plugin.LyricsId);
                tagNamesIds.Add(lyricsName, Plugin.LyricsId);
            }
            catch (ArgumentException)
            {
                file1.WriteLine("Cant add " + lyricsName + " / " + Plugin.LyricsId);

                try
                {
                    file1.WriteLine("Retry: adding " + lyricsName + lyricsNamePostfix + " / " + Plugin.LyricsId);
                    tagNamesIds.Add(lyricsName + lyricsNamePostfix, Plugin.LyricsId);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Retry: cant add " + lyricsName + lyricsNamePostfix + " / " + Plugin.LyricsId);
                }
            }
            try
            {
                file1.WriteLine("Adding " + synchronisedLyricsName + " / " + Plugin.SynchronisedLyricsId);
                tagNamesIds.Add(synchronisedLyricsName, Plugin.SynchronisedLyricsId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + synchronisedLyricsName + " / " + Plugin.SynchronisedLyricsId);
            }
            try
            {
                file1.WriteLine("Adding " + unsynchronisedLyricsName + " / " + Plugin.UnsynchronisedLyricsId);
                tagNamesIds.Add(unsynchronisedLyricsName, Plugin.UnsynchronisedLyricsId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + unsynchronisedLyricsName + " / " + Plugin.UnsynchronisedLyricsId);
            }
            try
            {
                file1.WriteLine("Adding " + nullTagName + " / " + Plugin.NullTagId);
                tagNamesIds.Add(nullTagName, Plugin.NullTagId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + nullTagName + " / " + Plugin.NullTagId);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom1) + " / " + Plugin.MetaDataType.Custom1);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom1), Plugin.MetaDataType.Custom1);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom1) + " / " + Plugin.MetaDataType.Custom1);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom2) + " / " + Plugin.MetaDataType.Custom2);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom2), Plugin.MetaDataType.Custom2);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom2) + " / " + Plugin.MetaDataType.Custom2);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom3) + " / " + Plugin.MetaDataType.Custom3);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom3), Plugin.MetaDataType.Custom3);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom3) + " / " + Plugin.MetaDataType.Custom3);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom4) + " / " + Plugin.MetaDataType.Custom4);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom4), Plugin.MetaDataType.Custom4);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom4) + " / " + Plugin.MetaDataType.Custom4);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom5) + " / " + Plugin.MetaDataType.Custom5);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom5), Plugin.MetaDataType.Custom5);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom5) + " / " + Plugin.MetaDataType.Custom5);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom6) + " / " + Plugin.MetaDataType.Custom6);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom6), Plugin.MetaDataType.Custom6);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom6) + " / " + Plugin.MetaDataType.Custom6);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom7) + " / " + Plugin.MetaDataType.Custom7);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom7), Plugin.MetaDataType.Custom7);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom7) + " / " + Plugin.MetaDataType.Custom7);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom8) + " / " + Plugin.MetaDataType.Custom8);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom8), Plugin.MetaDataType.Custom8);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom8) + " / " + Plugin.MetaDataType.Custom8);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom9) + " / " + Plugin.MetaDataType.Custom9);
                tagNamesIds.Add(custom9TagName, Plugin.MetaDataType.Custom9);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom9) + " / " + Plugin.MetaDataType.Custom9);
            }

            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom10) + " / " + Plugin.MetaDataType.Custom10);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom10), Plugin.MetaDataType.Custom10);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom10) + " / " + Plugin.MetaDataType.Custom10);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom11) + " / " + Plugin.MetaDataType.Custom11);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom11), Plugin.MetaDataType.Custom11);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom11) + " / " + Plugin.MetaDataType.Custom11);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom12) + " / " + Plugin.MetaDataType.Custom12);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom12), Plugin.MetaDataType.Custom12);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom12) + " / " + Plugin.MetaDataType.Custom12);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom13) + " / " + Plugin.MetaDataType.Custom13);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom13), Plugin.MetaDataType.Custom13);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom13) + " / " + Plugin.MetaDataType.Custom13);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom14) + " / " + Plugin.MetaDataType.Custom14);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom14), Plugin.MetaDataType.Custom14);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom14) + " / " + Plugin.MetaDataType.Custom14);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom15) + " / " + Plugin.MetaDataType.Custom15);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom15), Plugin.MetaDataType.Custom15);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom15) + " / " + Plugin.MetaDataType.Custom15);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom16) + " / " + Plugin.MetaDataType.Custom16);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom16), Plugin.MetaDataType.Custom16);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom16) + " / " + Plugin.MetaDataType.Custom16);
            }


            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genres) + " / " + Plugin.MetaDataType.Genres);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genres), Plugin.MetaDataType.Genres);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genres) + " / " + Plugin.MetaDataType.Genres);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Artists) + " / " + Plugin.MetaDataType.Artists);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Artists), Plugin.MetaDataType.Artists);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Artists) + " / " + Plugin.MetaDataType.Artists);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithArtistRole) + " / " + Plugin.MetaDataType.ArtistsWithArtistRole);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithArtistRole), Plugin.MetaDataType.ArtistsWithArtistRole);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithArtistRole) + " / " + Plugin.MetaDataType.ArtistsWithArtistRole);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithPerformerRole) + " / " + Plugin.MetaDataType.ArtistsWithPerformerRole);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithPerformerRole), Plugin.MetaDataType.ArtistsWithPerformerRole);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithPerformerRole) + " / " + Plugin.MetaDataType.ArtistsWithPerformerRole);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithGuestRole) + " / " + Plugin.MetaDataType.ArtistsWithGuestRole);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithGuestRole), Plugin.MetaDataType.ArtistsWithGuestRole);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithGuestRole) + " / " + Plugin.MetaDataType.ArtistsWithGuestRole);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithRemixerRole) + " / " + Plugin.MetaDataType.ArtistsWithRemixerRole);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithRemixerRole), Plugin.MetaDataType.ArtistsWithRemixerRole);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithRemixerRole) + " / " + Plugin.MetaDataType.ArtistsWithRemixerRole);
            }

            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.LastPlayed) + " / " + Plugin.FilePropertyType.LastPlayed);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.LastPlayed), (Plugin.MetaDataType)Plugin.FilePropertyType.LastPlayed);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.LastPlayed) + " / " + Plugin.FilePropertyType.LastPlayed);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.PlayCount) + " / " + Plugin.FilePropertyType.PlayCount);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.PlayCount), (Plugin.MetaDataType)Plugin.FilePropertyType.PlayCount);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.PlayCount) + " / " + Plugin.FilePropertyType.PlayCount);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SkipCount) + " / " + Plugin.FilePropertyType.SkipCount);
                tagNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SkipCount), (Plugin.MetaDataType)Plugin.FilePropertyType.SkipCount);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SkipCount) + " / " + Plugin.FilePropertyType.SkipCount);
            }

            if (wereErrors)
            {
                MessageBox.Show("Some tag names are duplicated. See '" + System.IO.Path.Combine(mbApiInterface.Setting_GetPersistentStoragePath(), "TagTools.TagNamesErrorLog.txt") + "' file for details. Plugin is not properly initialized.");
            }

            file1.Close();


            tagIdsNames.Add(Plugin.MetaDataType.TrackTitle, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackTitle));
            tagIdsNames.Add(Plugin.MetaDataType.Album, albumTagName);
            tagIdsNames.Add(Plugin.MetaDataType.AlbumArtist, displayedAlbumArtsistName);
            tagIdsNames.Add(Plugin.MetaDataType.AlbumArtistRaw, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.AlbumArtist));
            tagIdsNames.Add(Plugin.DisplayedArtistId, displayedArtistName);
            tagIdsNames.Add(Plugin.ArtistArtistsId, artistArtistsName);
            tagIdsNames.Add(Plugin.MetaDataType.Artwork, artworkName);
            tagIdsNames.Add(Plugin.MetaDataType.BeatsPerMin, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.BeatsPerMin));
            tagIdsNames.Add(Plugin.DisplayedComposerId, displayedComposerName);
            tagIdsNames.Add(Plugin.ComposerComposersId, composerComposersName);
            tagIdsNames.Add(Plugin.MetaDataType.Comment, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Comment));
            tagIdsNames.Add(Plugin.MetaDataType.Conductor, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Conductor));
            tagIdsNames.Add(Plugin.MetaDataType.DiscNo, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscNo));
            tagIdsNames.Add(Plugin.MetaDataType.DiscCount, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscCount));
            tagIdsNames.Add(Plugin.MetaDataType.Encoder, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Encoder));
            tagIdsNames.Add(Plugin.MetaDataType.Genre, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genre));
            tagIdsNames.Add(Plugin.MetaDataType.GenreCategory, genreCategoryName);
            tagIdsNames.Add(Plugin.MetaDataType.Grouping, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Grouping));
            tagIdsNames.Add(Plugin.MetaDataType.Keywords, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Keywords));
            tagIdsNames.Add(Plugin.MetaDataType.Lyricist, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Lyricist));
            tagIdsNames.Add(Plugin.MetaDataType.Mood, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Mood));
            tagIdsNames.Add(Plugin.MetaDataType.Occasion, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Occasion));
            tagIdsNames.Add(Plugin.MetaDataType.Origin, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Origin));
            tagIdsNames.Add(Plugin.MetaDataType.Publisher, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Publisher));
            tagIdsNames.Add(Plugin.MetaDataType.Quality, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Quality));
            tagIdsNames.Add(Plugin.MetaDataType.Rating, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Rating));
            tagIdsNames.Add(Plugin.MetaDataType.RatingAlbum, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingAlbum));
            tagIdsNames.Add(Plugin.MetaDataType.RatingLove, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingLove));
            tagIdsNames.Add(Plugin.MetaDataType.Tempo, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Tempo));
            tagIdsNames.Add(Plugin.MetaDataType.TrackNo, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackNo));
            tagIdsNames.Add(Plugin.MetaDataType.TrackCount, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackCount));
            tagIdsNames.Add(Plugin.MetaDataType.Year, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Year));
            tagIdsNames.Add(Plugin.MetaDataType.HasLyrics, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.HasLyrics));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual1, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual1));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual2, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual2));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual3, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual3));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual4, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual4));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual5, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual5));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual6, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual6));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual7, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual7));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual8, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual8));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual9, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual9));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual10, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual10));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual11, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual11));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual12, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual12));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual13, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual13));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual14, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual14));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual15, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual15));
            tagIdsNames.Add(Plugin.MetaDataType.Virtual16, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual16));

            tagIdsNames.Add(Plugin.LyricsId, lyricsName);
            tagIdsNames.Add(Plugin.SynchronisedLyricsId, synchronisedLyricsName);
            tagIdsNames.Add(Plugin.UnsynchronisedLyricsId, unsynchronisedLyricsName);

            tagIdsNames.Add(Plugin.NullTagId, nullTagName);

            tagIdsNames.Add(Plugin.MetaDataType.Custom1, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom1));
            tagIdsNames.Add(Plugin.MetaDataType.Custom2, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom2));
            tagIdsNames.Add(Plugin.MetaDataType.Custom3, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom3));
            tagIdsNames.Add(Plugin.MetaDataType.Custom4, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom4));
            tagIdsNames.Add(Plugin.MetaDataType.Custom5, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom5));
            tagIdsNames.Add(Plugin.MetaDataType.Custom6, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom6));
            tagIdsNames.Add(Plugin.MetaDataType.Custom7, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom7));
            tagIdsNames.Add(Plugin.MetaDataType.Custom8, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom8));
            tagIdsNames.Add(Plugin.MetaDataType.Custom9, custom9TagName);
            tagIdsNames.Add(Plugin.MetaDataType.Custom10, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom10));
            tagIdsNames.Add(Plugin.MetaDataType.Custom11, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom11));
            tagIdsNames.Add(Plugin.MetaDataType.Custom12, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom12));
            tagIdsNames.Add(Plugin.MetaDataType.Custom13, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom13));
            tagIdsNames.Add(Plugin.MetaDataType.Custom14, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom14));
            tagIdsNames.Add(Plugin.MetaDataType.Custom15, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom15));
            tagIdsNames.Add(Plugin.MetaDataType.Custom16, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom16));


            tagIdsNames.Add(Plugin.MetaDataType.Genres, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genres));
            tagIdsNames.Add(Plugin.MetaDataType.Artists, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Artists));
            tagIdsNames.Add(Plugin.MetaDataType.ArtistsWithArtistRole, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithArtistRole));
            tagIdsNames.Add(Plugin.MetaDataType.ArtistsWithPerformerRole, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithPerformerRole));
            tagIdsNames.Add(Plugin.MetaDataType.ArtistsWithGuestRole, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithGuestRole));
            tagIdsNames.Add(Plugin.MetaDataType.ArtistsWithRemixerRole, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.ArtistsWithRemixerRole));

            tagIdsNames.Add((Plugin.MetaDataType)Plugin.FilePropertyType.LastPlayed, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.LastPlayed));
            tagIdsNames.Add((Plugin.MetaDataType)Plugin.FilePropertyType.PlayCount, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.PlayCount));
            tagIdsNames.Add((Plugin.MetaDataType)Plugin.FilePropertyType.SkipCount, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SkipCount));


            wereErrors = false;
            Encoding unicode2 = Encoding.UTF8;
            System.IO.FileStream stream2 = System.IO.File.Open(System.IO.Path.Combine(mbApiInterface.Setting_GetPersistentStoragePath(), "TagTools.PropNamesErrorLog.txt"), System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None);
            System.IO.StreamWriter file2 = new System.IO.StreamWriter(stream2, unicode2);

            propNamesIds.Clear();
            propIdsNames.Clear();

            try
            {
                file2.WriteLine("Adding " + urlTagName + " / " + Plugin.FilePropertyType.Url);
                propNamesIds.Add(urlTagName, Plugin.FilePropertyType.Url);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + urlTagName + " / " + Plugin.FilePropertyType.Url);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Kind) + " / " + Plugin.FilePropertyType.Kind);
                propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Kind), Plugin.FilePropertyType.Kind);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Kind) + " / " + Plugin.FilePropertyType.Kind);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Format) + " / " + Plugin.FilePropertyType.Format);
                propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Format), Plugin.FilePropertyType.Format);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Format) + " / " + Plugin.FilePropertyType.Format);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Size) + " / " + Plugin.FilePropertyType.Size);
                propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Size), Plugin.FilePropertyType.Size);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Size) + " / " + Plugin.FilePropertyType.Size);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Channels) + " / " + Plugin.FilePropertyType.Channels);
                propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Channels), Plugin.FilePropertyType.Channels);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Channels) + " / " + Plugin.FilePropertyType.Channels);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SampleRate) + " / " + Plugin.FilePropertyType.SampleRate);
                propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SampleRate), Plugin.FilePropertyType.SampleRate);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SampleRate) + " / " + Plugin.FilePropertyType.SampleRate);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Bitrate) + " / " + Plugin.FilePropertyType.Bitrate);
                propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Bitrate), Plugin.FilePropertyType.Bitrate);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Bitrate) + " / " + Plugin.FilePropertyType.Bitrate);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateModified) + " / " + Plugin.FilePropertyType.DateModified);
                propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateModified), Plugin.FilePropertyType.DateModified);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateModified) + " / " + Plugin.FilePropertyType.DateModified);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateAdded) + " / " + Plugin.FilePropertyType.DateAdded);
                propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateAdded), Plugin.FilePropertyType.DateAdded);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateAdded) + " / " + Plugin.FilePropertyType.DateAdded);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Duration) + " / " + Plugin.FilePropertyType.Duration);
                propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Duration), Plugin.FilePropertyType.Duration);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Duration) + " / " + Plugin.FilePropertyType.Duration);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainTrack) + " / " + Plugin.FilePropertyType.ReplayGainTrack);
                propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainTrack), Plugin.FilePropertyType.ReplayGainTrack);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainTrack) + " / " + Plugin.FilePropertyType.ReplayGainTrack);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainAlbum) + " / " + Plugin.FilePropertyType.ReplayGainAlbum);
                propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainAlbum), Plugin.FilePropertyType.ReplayGainAlbum);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainAlbum) + " / " + Plugin.FilePropertyType.ReplayGainAlbum);
            }

            if (wereErrors)
            {
                MessageBox.Show("Some track property names are duplicated. See '" + System.IO.Path.Combine(mbApiInterface.Setting_GetPersistentStoragePath(), "TagTools.PropNamesErrorLog.txt") + "' file for details. Plugin is not properly initialized.");
            }

            file2.Close();


            propIdsNames.Add(Plugin.FilePropertyType.Url, urlTagName);
            propIdsNames.Add(Plugin.FilePropertyType.Kind, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Kind));
            propIdsNames.Add(Plugin.FilePropertyType.Format, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Format));
            propIdsNames.Add(Plugin.FilePropertyType.Size, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Size));
            propIdsNames.Add(Plugin.FilePropertyType.Channels, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Channels));
            propIdsNames.Add(Plugin.FilePropertyType.SampleRate, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SampleRate));
            propIdsNames.Add(Plugin.FilePropertyType.Bitrate, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Bitrate));
            propIdsNames.Add(Plugin.FilePropertyType.DateModified, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateModified));
            propIdsNames.Add(Plugin.FilePropertyType.DateAdded, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateAdded));
            propIdsNames.Add(Plugin.FilePropertyType.Duration, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Duration));
            propIdsNames.Add(Plugin.FilePropertyType.ReplayGainTrack, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainTrack));
            propIdsNames.Add(Plugin.FilePropertyType.ReplayGainAlbum, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainAlbum));
        }
    }
}
