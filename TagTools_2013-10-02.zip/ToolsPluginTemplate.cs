﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using System.Threading;

namespace MusicBeePlugin
{
    public partial class ToolsPluginTemplate : Form
    {
        private delegate void StopButtonClicked(ToolsPluginTemplate clickedForm);
        private delegate void TaskStarted();
        protected delegate bool PrepareOperation();

        private StopButtonClicked stopButtonClicked;
        private TaskStarted taskStarted;

        protected Plugin tagToolsPlugin;
        protected Plugin.MusicBeeApiInterface mbApiInterface;

        private Thread backgroundThread = null;
        protected ThreadStart job;

        public bool backgroundTaskIsScheduled = false;
        public bool backgroundTaskIsNativeMB = false;
        public bool backgroundTaskIsCanceled = false;

        public bool previewIsGenerated = false;

        protected Button clickedButton;
        protected string clickedButtonText;

        protected Button closeButton;
        protected string closeButtonText;

        protected Button previewButton;

        private FormWindowState windowState;
        private int windowWidth;
        private int windowHeight;

        public bool backgroundTaskIsWorking()
        {
            lock (taskStarted)
            {
                if (backgroundTaskIsScheduled && !backgroundTaskIsCanceled)
                {
                    return true;
                }
            }

            return false;
        }

        public ToolsPluginTemplate()
        {
            InitializeComponent();
        }

        public ToolsPluginTemplate(Plugin tagToolsPluginParam)
        {
            InitializeComponent();

            tagToolsPlugin = tagToolsPluginParam;

            initializeForm();
        }

        protected void initializeForm()
        {
            mbApiInterface = tagToolsPlugin.mbApiInterface;

            tagToolsPlugin.mbForm.AddOwnedForm(this);

            clickedButton = tagToolsPlugin.emptyButton;

            lock (tagToolsPlugin.openedForms)
            {
                if (tagToolsPlugin.numberOfNativeMbBackgroundTasks > 0)
                    disableQueryingButtons();
                else
                    enableQueryingButtons();
            }

            stopButtonClicked = stopButtonClickedMethod;
            taskStarted = taskStartedMethod;

            if (Plugin.SavedSettings.useSkinColors)
            {
                this.BackColor = Color.FromArgb(mbApiInterface.Setting_GetSkinElementColour(Plugin.SkinElement.SkinInputPanel, Plugin.ElementState.ElementStateDefault, Plugin.ElementComponent.ComponentBackground));
                this.ForeColor = Color.FromArgb(mbApiInterface.Setting_GetSkinElementColour(Plugin.SkinElement.SkinInputPanel, Plugin.ElementState.ElementStateDefault, Plugin.ElementComponent.ComponentForeground));

                foreach (Control control in this.Controls)
                {
                    if (control.GetType() == clickedButton.GetType())
                    {
                        control.BackColor = Color.FromArgb(mbApiInterface.Setting_GetSkinElementColour(Plugin.SkinElement.SkinInputControl, Plugin.ElementState.ElementStateDefault, Plugin.ElementComponent.ComponentBackground));
                    }
                    else
                    {
                        control.BackColor = Color.FromArgb(mbApiInterface.Setting_GetSkinElementColour(Plugin.SkinElement.SkinInputPanel, Plugin.ElementState.ElementStateDefault, Plugin.ElementComponent.ComponentBackground));
                    }
                    control.ForeColor = Color.FromArgb(mbApiInterface.Setting_GetSkinElementColour(Plugin.SkinElement.SkinInputControl, Plugin.ElementState.ElementStateDefault, Plugin.ElementComponent.ComponentForeground));
                }
            }

            string fullName = this.GetType().FullName;
            for (int i = 0; i < Plugin.NumberOfCommands; i++)
            {
                if (Plugin.SavedSettings.forms[i] == fullName)
                {
                    if (Plugin.SavedSettings.sizesPositions[i].w != 0)
                    {
                        this.DesktopLocation = new Point(Plugin.SavedSettings.sizesPositions[i].x, Plugin.SavedSettings.sizesPositions[i].y);
                        this.Size = new Size(Plugin.SavedSettings.sizesPositions[i].w, Plugin.SavedSettings.sizesPositions[i].h);

                        if (Plugin.SavedSettings.sizesPositions[i].max)
                            WindowState = FormWindowState.Maximized;

                        break;
                    }
                }
            }

            fillTagNames();
        }

        private void fillTagNames()
        {
            if (mbApiInterface.ApiRevision >= 27)
                tagToolsPlugin.readonlyTagsNames = new string[22];
            else
                tagToolsPlugin.readonlyTagsNames = new string[15];

            tagToolsPlugin.readonlyTagsNames[0] = tagToolsPlugin.genreCategoryName;
            tagToolsPlugin.readonlyTagsNames[1] = tagToolsPlugin.lyricsName;
            tagToolsPlugin.readonlyTagsNames[2] = tagToolsPlugin.synchronisedLyricsName;
            tagToolsPlugin.readonlyTagsNames[3] = tagToolsPlugin.unsynchronisedLyricsName;
            tagToolsPlugin.readonlyTagsNames[4] = tagToolsPlugin.displayedAlbumArtsistName;
            tagToolsPlugin.readonlyTagsNames[5] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.HasLyrics);
            tagToolsPlugin.readonlyTagsNames[6] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual1);
            tagToolsPlugin.readonlyTagsNames[7] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual2);
            tagToolsPlugin.readonlyTagsNames[8] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual3);
            tagToolsPlugin.readonlyTagsNames[9] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual4);
            tagToolsPlugin.readonlyTagsNames[10] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual5);
            tagToolsPlugin.readonlyTagsNames[11] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual6);
            tagToolsPlugin.readonlyTagsNames[12] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual7);
            tagToolsPlugin.readonlyTagsNames[13] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual8);
            tagToolsPlugin.readonlyTagsNames[14] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual9);
            if (mbApiInterface.ApiRevision >= 27)
            {
                tagToolsPlugin.readonlyTagsNames[15] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual10);
                tagToolsPlugin.readonlyTagsNames[16] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual11);
                tagToolsPlugin.readonlyTagsNames[17] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual12);
                tagToolsPlugin.readonlyTagsNames[18] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual13);
                tagToolsPlugin.readonlyTagsNames[19] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual14);
                tagToolsPlugin.readonlyTagsNames[20] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual15);
                tagToolsPlugin.readonlyTagsNames[21] = mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual16);
            }

            //Tags
            bool wereErrors = false;
            Encoding unicode1 = Encoding.UTF8;
            System.IO.FileStream stream1 = System.IO.File.Open("C:\\Windows\\Temp\\TagTools.TagNamesErrorLog.txt", System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None);
            System.IO.StreamWriter file1 = new System.IO.StreamWriter(stream1, unicode1);

            tagToolsPlugin.tagNamesIds.Clear();
            tagToolsPlugin.tagIdsNames.Clear();

            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackTitle) + " / " + Plugin.MetaDataType.TrackTitle);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackTitle), Plugin.MetaDataType.TrackTitle);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackTitle) + " / " + Plugin.MetaDataType.TrackTitle);
            }
            try
            {
                file1.WriteLine("Adding " + tagToolsPlugin.albumTagName + " / " + Plugin.MetaDataType.Album);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.albumTagName, Plugin.MetaDataType.Album);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + tagToolsPlugin.albumTagName + " / " + Plugin.MetaDataType.Album);
            }
            try
            {
                file1.WriteLine("Adding " + tagToolsPlugin.displayedAlbumArtsistName + " / " + Plugin.MetaDataType.AlbumArtist);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.displayedAlbumArtsistName, Plugin.MetaDataType.AlbumArtist);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + tagToolsPlugin.displayedAlbumArtsistName + " / " + Plugin.MetaDataType.AlbumArtist);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.AlbumArtist) + " / " + Plugin.MetaDataType.AlbumArtistRaw);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.AlbumArtist), Plugin.MetaDataType.AlbumArtistRaw);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.AlbumArtist) + " / " + Plugin.MetaDataType.AlbumArtistRaw);
            }
            try
            {
                file1.WriteLine("Adding " + tagToolsPlugin.displayedArtistName + " / " + Plugin.DisplayedArtistId);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.displayedArtistName, Plugin.DisplayedArtistId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + tagToolsPlugin.displayedArtistName + " / " + Plugin.DisplayedArtistId);
            }
            try
            {
                file1.WriteLine("Adding " + tagToolsPlugin.artistArtistsName + " / " + Plugin.ArtistArtistsId);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.artistArtistsName, Plugin.ArtistArtistsId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + tagToolsPlugin.artistArtistsName + " / " + Plugin.ArtistArtistsId);
            }
            try
            {
                file1.WriteLine("Adding " + tagToolsPlugin.artworkName + " / " + Plugin.MetaDataType.Artwork);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.artworkName, Plugin.MetaDataType.Artwork);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + tagToolsPlugin.artworkName + " / " + Plugin.MetaDataType.Artwork);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.BeatsPerMin) + " / " + Plugin.MetaDataType.BeatsPerMin);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.BeatsPerMin), Plugin.MetaDataType.BeatsPerMin);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.BeatsPerMin) + " / " + Plugin.MetaDataType.BeatsPerMin);
            }
            try
            {
                file1.WriteLine("Adding " + tagToolsPlugin.displayedComposerName + " / " + Plugin.DisplayedComposerId);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.displayedComposerName, Plugin.DisplayedComposerId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + tagToolsPlugin.displayedComposerName + " / " + Plugin.DisplayedComposerId);
            }
            try
            {
                file1.WriteLine("Adding " + tagToolsPlugin.composerComposersName + " / " + Plugin.ComposerComposersId);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.composerComposersName, Plugin.ComposerComposersId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + tagToolsPlugin.composerComposersName + " / " + Plugin.ComposerComposersId);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Comment) + " / " + Plugin.MetaDataType.Comment);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Comment), Plugin.MetaDataType.Comment);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Comment) + " / " + Plugin.MetaDataType.Comment);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Conductor) + " / " + Plugin.MetaDataType.Conductor);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Conductor), Plugin.MetaDataType.Conductor);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Conductor) + " / " + Plugin.MetaDataType.Conductor);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscNo) + " / " + Plugin.MetaDataType.DiscNo);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscNo), Plugin.MetaDataType.DiscNo);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscNo) + " / " + Plugin.MetaDataType.DiscNo);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscCount) + " / " + Plugin.MetaDataType.DiscCount);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscCount), Plugin.MetaDataType.DiscCount);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscCount) + " / " + Plugin.MetaDataType.DiscCount);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Encoder) + " / " + Plugin.MetaDataType.Encoder);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Encoder), Plugin.MetaDataType.Encoder);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Encoder) + " / " + Plugin.MetaDataType.Encoder);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genre) + " / " + Plugin.MetaDataType.Genre);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genre), Plugin.MetaDataType.Genre);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genre) + " / " + Plugin.MetaDataType.Genre);
            }
            try
            {
                file1.WriteLine("Adding " + tagToolsPlugin.genreCategoryName + " / " + Plugin.MetaDataType.GenreCategory);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.genreCategoryName, Plugin.MetaDataType.GenreCategory);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + tagToolsPlugin.genreCategoryName + " / " + Plugin.MetaDataType.GenreCategory);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Grouping) + " / " + Plugin.MetaDataType.Grouping);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Grouping), Plugin.MetaDataType.Grouping);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Grouping) + " / " + Plugin.MetaDataType.Grouping);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Keywords) + " / " + Plugin.MetaDataType.Keywords);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Keywords), Plugin.MetaDataType.Keywords);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Keywords) + " / " + Plugin.MetaDataType.Keywords);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Lyricist) + " / " + Plugin.MetaDataType.Lyricist);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Lyricist), Plugin.MetaDataType.Lyricist);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Lyricist) + " / " + Plugin.MetaDataType.Lyricist);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Mood) + " / " + Plugin.MetaDataType.Mood);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Mood), Plugin.MetaDataType.Mood);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Mood) + " / " + Plugin.MetaDataType.Mood);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Occasion) + " / " + Plugin.MetaDataType.Occasion);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Occasion), Plugin.MetaDataType.Occasion);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Occasion) + " / " + Plugin.MetaDataType.Occasion);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Origin) + " / " + Plugin.MetaDataType.Origin);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Origin), Plugin.MetaDataType.Origin);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Origin) + " / " + Plugin.MetaDataType.Origin);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Publisher) + " / " + Plugin.MetaDataType.Publisher);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Publisher), Plugin.MetaDataType.Publisher);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Publisher) + " / " + Plugin.MetaDataType.Publisher);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Quality) + " / " + Plugin.MetaDataType.Quality);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Quality), Plugin.MetaDataType.Quality);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Quality) + " / " + Plugin.MetaDataType.Quality);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Rating) + " / " + Plugin.MetaDataType.Rating);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Rating), Plugin.MetaDataType.Rating);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Rating) + " / " + Plugin.MetaDataType.Rating);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingAlbum) + " / " + Plugin.MetaDataType.RatingAlbum);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingAlbum), Plugin.MetaDataType.RatingAlbum);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingAlbum) + " / " + Plugin.MetaDataType.RatingAlbum);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingLove) + " / " + Plugin.MetaDataType.RatingLove);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingLove), Plugin.MetaDataType.RatingLove);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingLove) + " / " + Plugin.MetaDataType.RatingLove);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Tempo) + " / " + Plugin.MetaDataType.Tempo);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Tempo), Plugin.MetaDataType.Tempo);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Tempo) + " / " + Plugin.MetaDataType.Tempo);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackNo) + " / " + Plugin.MetaDataType.TrackNo);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackNo), Plugin.MetaDataType.TrackNo);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackNo) + " / " + Plugin.MetaDataType.TrackNo);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackCount) + " / " + Plugin.MetaDataType.TrackCount);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackCount), Plugin.MetaDataType.TrackCount);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackCount) + " / " + Plugin.MetaDataType.TrackCount);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Year) + " / " + Plugin.MetaDataType.Year);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Year), Plugin.MetaDataType.Year);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Year) + " / " + Plugin.MetaDataType.Year);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.HasLyrics) + " / " + Plugin.MetaDataType.HasLyrics);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.HasLyrics), Plugin.MetaDataType.HasLyrics);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.HasLyrics) + " / " + Plugin.MetaDataType.HasLyrics);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual1) + " / " + Plugin.MetaDataType.Virtual1);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual1), Plugin.MetaDataType.Virtual1);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual1) + " / " + Plugin.MetaDataType.Virtual1);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual2) + " / " + Plugin.MetaDataType.Virtual2);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual2), Plugin.MetaDataType.Virtual2);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual2) + " / " + Plugin.MetaDataType.Virtual2);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual3) + " / " + Plugin.MetaDataType.Virtual3);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual3), Plugin.MetaDataType.Virtual3);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual3) + " / " + Plugin.MetaDataType.Virtual3);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual4) + " / " + Plugin.MetaDataType.Virtual4);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual4), Plugin.MetaDataType.Virtual4);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual4) + " / " + Plugin.MetaDataType.Virtual4);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual5) + " / " + Plugin.MetaDataType.Virtual5);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual5), Plugin.MetaDataType.Virtual5);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual5) + " / " + Plugin.MetaDataType.Virtual5);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual6) + " / " + Plugin.MetaDataType.Virtual6);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual6), Plugin.MetaDataType.Virtual6);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual6) + " / " + Plugin.MetaDataType.Virtual6);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual7) + " / " + Plugin.MetaDataType.Virtual7);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual7), Plugin.MetaDataType.Virtual7);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual7) + " / " + Plugin.MetaDataType.Virtual7);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual8) + " / " + Plugin.MetaDataType.Virtual8);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual8), Plugin.MetaDataType.Virtual8);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual8) + " / " + Plugin.MetaDataType.Virtual8);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual9) + " / " + Plugin.MetaDataType.Virtual9);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual9), Plugin.MetaDataType.Virtual9);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual9) + " / " + Plugin.MetaDataType.Virtual9);
            }

            if (mbApiInterface.ApiRevision >= 27)
            {
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual10) + " / " + Plugin.MetaDataType.Virtual10);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual10), Plugin.MetaDataType.Virtual10);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual10) + " / " + Plugin.MetaDataType.Virtual10);
                }
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual11) + " / " + Plugin.MetaDataType.Virtual11);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual11), Plugin.MetaDataType.Virtual11);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual11) + " / " + Plugin.MetaDataType.Virtual11);
                }
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual12) + " / " + Plugin.MetaDataType.Virtual12);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual12), Plugin.MetaDataType.Virtual12);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual12) + " / " + Plugin.MetaDataType.Virtual12);
                }
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual13) + " / " + Plugin.MetaDataType.Virtual13);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual13), Plugin.MetaDataType.Virtual13);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual13) + " / " + Plugin.MetaDataType.Virtual13);
                }
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual14) + " / " + Plugin.MetaDataType.Virtual14);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual14), Plugin.MetaDataType.Virtual14);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual14) + " / " + Plugin.MetaDataType.Virtual14);
                }
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual15) + " / " + Plugin.MetaDataType.Virtual15);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual15), Plugin.MetaDataType.Virtual15);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual15) + " / " + Plugin.MetaDataType.Virtual15);
                }
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual16) + " / " + Plugin.MetaDataType.Virtual16);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual16), Plugin.MetaDataType.Virtual16);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual16) + " / " + Plugin.MetaDataType.Virtual16);
                }
            }


            try
            {
                file1.WriteLine("Adding " + tagToolsPlugin.lyricsName + " / " + Plugin.LyricsId);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.lyricsName, Plugin.LyricsId);
            }
            catch (ArgumentException)
            {
                file1.WriteLine("Cant add " + tagToolsPlugin.lyricsName + " / " + Plugin.LyricsId);

                try
                {
                    file1.WriteLine("Retry: adding " + tagToolsPlugin.lyricsName + tagToolsPlugin.lyricsNamePostfix + " / " + Plugin.LyricsId);
                    tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.lyricsName + tagToolsPlugin.lyricsNamePostfix, Plugin.LyricsId);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Retry: cant add " + tagToolsPlugin.lyricsName + tagToolsPlugin.lyricsNamePostfix + " / " + Plugin.LyricsId);
                }
            }
            try
            {
                file1.WriteLine("Adding " + tagToolsPlugin.synchronisedLyricsName + " / " + Plugin.SynchronisedLyricsId);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.synchronisedLyricsName, Plugin.SynchronisedLyricsId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + tagToolsPlugin.synchronisedLyricsName + " / " + Plugin.SynchronisedLyricsId);
            }
            try
            {
                file1.WriteLine("Adding " + tagToolsPlugin.unsynchronisedLyricsName + " / " + Plugin.UnsynchronisedLyricsId);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.unsynchronisedLyricsName, Plugin.UnsynchronisedLyricsId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + tagToolsPlugin.unsynchronisedLyricsName + " / " + Plugin.UnsynchronisedLyricsId);
            }
            try
            {
                file1.WriteLine("Adding " + tagToolsPlugin.nullTagName + " / " + Plugin.NullTagId);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.nullTagName, Plugin.NullTagId);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + tagToolsPlugin.nullTagName + " / " + Plugin.NullTagId);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom1) + " / " + Plugin.MetaDataType.Custom1);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom1), Plugin.MetaDataType.Custom1);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom1) + " / " + Plugin.MetaDataType.Custom1);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom2) + " / " + Plugin.MetaDataType.Custom2);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom2), Plugin.MetaDataType.Custom2);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom2) + " / " + Plugin.MetaDataType.Custom2);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom3) + " / " + Plugin.MetaDataType.Custom3);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom3), Plugin.MetaDataType.Custom3);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom3) + " / " + Plugin.MetaDataType.Custom3);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom4) + " / " + Plugin.MetaDataType.Custom4);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom4), Plugin.MetaDataType.Custom4);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom4) + " / " + Plugin.MetaDataType.Custom4);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom5) + " / " + Plugin.MetaDataType.Custom5);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom5), Plugin.MetaDataType.Custom5);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom5) + " / " + Plugin.MetaDataType.Custom5);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom6) + " / " + Plugin.MetaDataType.Custom6);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom6), Plugin.MetaDataType.Custom6);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom6) + " / " + Plugin.MetaDataType.Custom6);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom7) + " / " + Plugin.MetaDataType.Custom7);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom7), Plugin.MetaDataType.Custom7);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom7) + " / " + Plugin.MetaDataType.Custom7);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom8) + " / " + Plugin.MetaDataType.Custom8);
                tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom8), Plugin.MetaDataType.Custom8);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom8) + " / " + Plugin.MetaDataType.Custom8);
            }
            try
            {
                file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom9) + " / " + Plugin.MetaDataType.Custom9);
                tagToolsPlugin.tagNamesIds.Add(tagToolsPlugin.custom9TagName, Plugin.MetaDataType.Custom9);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom9) + " / " + Plugin.MetaDataType.Custom9);
            }

            if (mbApiInterface.ApiRevision >= 27)
            {
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom10) + " / " + Plugin.MetaDataType.Custom10);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom10), Plugin.MetaDataType.Custom10);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom10) + " / " + Plugin.MetaDataType.Custom10);
                }
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom11) + " / " + Plugin.MetaDataType.Custom11);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom11), Plugin.MetaDataType.Custom11);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom11) + " / " + Plugin.MetaDataType.Custom11);
                }
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom12) + " / " + Plugin.MetaDataType.Custom12);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom12), Plugin.MetaDataType.Custom12);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom12) + " / " + Plugin.MetaDataType.Custom12);
                }
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom13) + " / " + Plugin.MetaDataType.Custom13);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom13), Plugin.MetaDataType.Custom13);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom13) + " / " + Plugin.MetaDataType.Custom13);
                }
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom14) + " / " + Plugin.MetaDataType.Custom14);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom14), Plugin.MetaDataType.Custom14);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom14) + " / " + Plugin.MetaDataType.Custom14);
                }
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom15) + " / " + Plugin.MetaDataType.Custom15);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom15), Plugin.MetaDataType.Custom15);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom15) + " / " + Plugin.MetaDataType.Custom15);
                }
                try
                {
                    file1.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom16) + " / " + Plugin.MetaDataType.Custom16);
                    tagToolsPlugin.tagNamesIds.Add(mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom16), Plugin.MetaDataType.Custom16);
                }
                catch (ArgumentException)
                {
                    wereErrors = true;
                    file1.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom16) + " / " + Plugin.MetaDataType.Custom16);
                }
            }

            if (wereErrors)
            {
                MessageBox.Show("Some tag names are duplicated. See 'C:\\Windows\\Temp\\TagTools.TagNamesErrorLog.txt' file for details. Plugin is not properly initialized.");
            }

            file1.Close();


            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.TrackTitle, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackTitle));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Album, tagToolsPlugin.albumTagName);
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.AlbumArtist, tagToolsPlugin.displayedAlbumArtsistName);
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.AlbumArtistRaw, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.AlbumArtist));
            tagToolsPlugin.tagIdsNames.Add(Plugin.DisplayedArtistId, tagToolsPlugin.displayedArtistName);
            tagToolsPlugin.tagIdsNames.Add(Plugin.ArtistArtistsId, tagToolsPlugin.artistArtistsName);
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Artwork, tagToolsPlugin.artworkName);
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.BeatsPerMin, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.BeatsPerMin));
            tagToolsPlugin.tagIdsNames.Add(Plugin.DisplayedComposerId, tagToolsPlugin.displayedComposerName);
            tagToolsPlugin.tagIdsNames.Add(Plugin.ComposerComposersId, tagToolsPlugin.composerComposersName);
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Comment, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Comment));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Conductor, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Conductor));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.DiscNo, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscNo));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.DiscCount, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.DiscCount));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Encoder, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Encoder));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Genre, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Genre));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.GenreCategory, tagToolsPlugin.genreCategoryName);
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Grouping, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Grouping));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Keywords, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Keywords));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Lyricist, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Lyricist));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Mood, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Mood));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Occasion, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Occasion));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Origin, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Origin));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Publisher, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Publisher));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Quality, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Quality));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Rating, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Rating));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.RatingAlbum, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingAlbum));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.RatingLove, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.RatingLove));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Tempo, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Tempo));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.TrackNo, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackNo));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.TrackCount, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.TrackCount));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Year, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Year));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.HasLyrics, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.HasLyrics));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual1, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual1));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual2, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual2));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual3, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual3));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual4, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual4));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual5, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual5));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual6, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual6));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual7, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual7));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual8, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual8));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual9, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual9));
            if (mbApiInterface.ApiRevision >= 27)
            {
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual10, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual10));
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual11, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual11));
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual12, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual12));
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual13, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual13));
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual14, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual14));
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual15, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual15));
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Virtual16, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Virtual16));
            }

            tagToolsPlugin.tagIdsNames.Add(Plugin.LyricsId, tagToolsPlugin.lyricsName);
            tagToolsPlugin.tagIdsNames.Add(Plugin.SynchronisedLyricsId, tagToolsPlugin.synchronisedLyricsName);
            tagToolsPlugin.tagIdsNames.Add(Plugin.UnsynchronisedLyricsId, tagToolsPlugin.unsynchronisedLyricsName);

            tagToolsPlugin.tagIdsNames.Add(Plugin.NullTagId, tagToolsPlugin.nullTagName);

            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom1, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom1));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom2, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom2));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom3, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom3));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom4, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom4));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom5, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom5));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom6, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom6));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom7, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom7));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom8, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom8));
            tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom9, tagToolsPlugin.custom9TagName);
            if (mbApiInterface.ApiRevision >= 27)
            {
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom10, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom10));
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom11, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom11));
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom12, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom12));
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom13, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom13));
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom14, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom14));
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom15, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom15));
                tagToolsPlugin.tagIdsNames.Add(Plugin.MetaDataType.Custom16, mbApiInterface.Setting_GetFieldName(Plugin.MetaDataType.Custom16));
            }


            wereErrors = false;
            Encoding unicode2 = Encoding.UTF8;
            System.IO.FileStream stream2 = System.IO.File.Open("C:\\Windows\\Temp\\TagTools.PropNamesErrorLog.txt", System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None);
            System.IO.StreamWriter file2 = new System.IO.StreamWriter(stream2, unicode2);

            tagToolsPlugin.propNamesIds.Clear();
            tagToolsPlugin.propIdsNames.Clear();

            try
            {
                file2.WriteLine("Adding " + tagToolsPlugin.urlTagName + " / " + Plugin.FilePropertyType.Url);
                tagToolsPlugin.propNamesIds.Add(tagToolsPlugin.urlTagName, Plugin.FilePropertyType.Url);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + tagToolsPlugin.urlTagName + " / " + Plugin.FilePropertyType.Url);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Kind) + " / " + Plugin.FilePropertyType.Kind);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Kind), Plugin.FilePropertyType.Kind);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Kind) + " / " + Plugin.FilePropertyType.Kind);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Format) + " / " + Plugin.FilePropertyType.Format);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Format), Plugin.FilePropertyType.Format);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Format) + " / " + Plugin.FilePropertyType.Format);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Size) + " / " + Plugin.FilePropertyType.Size);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Size), Plugin.FilePropertyType.Size);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Size) + " / " + Plugin.FilePropertyType.Size);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Channels) + " / " + Plugin.FilePropertyType.Channels);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Channels), Plugin.FilePropertyType.Channels);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Channels) + " / " + Plugin.FilePropertyType.Channels);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SampleRate) + " / " + Plugin.FilePropertyType.SampleRate);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SampleRate), Plugin.FilePropertyType.SampleRate);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SampleRate) + " / " + Plugin.FilePropertyType.SampleRate);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Bitrate) + " / " + Plugin.FilePropertyType.Bitrate);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Bitrate), Plugin.FilePropertyType.Bitrate);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Bitrate) + " / " + Plugin.FilePropertyType.Bitrate);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateModified) + " / " + Plugin.FilePropertyType.DateModified);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateModified), Plugin.FilePropertyType.DateModified);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateModified) + " / " + Plugin.FilePropertyType.DateModified);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateAdded) + " / " + Plugin.FilePropertyType.DateAdded);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateAdded), Plugin.FilePropertyType.DateAdded);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateAdded) + " / " + Plugin.FilePropertyType.DateAdded);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.LastPlayed) + " / " + Plugin.FilePropertyType.LastPlayed);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.LastPlayed), Plugin.FilePropertyType.LastPlayed);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.LastPlayed) + " / " + Plugin.FilePropertyType.LastPlayed);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.PlayCount) + " / " + Plugin.FilePropertyType.PlayCount);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.PlayCount), Plugin.FilePropertyType.PlayCount);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.PlayCount) + " / " + Plugin.FilePropertyType.PlayCount);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SkipCount) + " / " + Plugin.FilePropertyType.SkipCount);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SkipCount), Plugin.FilePropertyType.SkipCount);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SkipCount) + " / " + Plugin.FilePropertyType.SkipCount);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Duration) + " / " + Plugin.FilePropertyType.Duration);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Duration), Plugin.FilePropertyType.Duration);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Duration) + " / " + Plugin.FilePropertyType.Duration);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainTrack) + " / " + Plugin.FilePropertyType.ReplayGainTrack);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainTrack), Plugin.FilePropertyType.ReplayGainTrack);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainTrack) + " / " + Plugin.FilePropertyType.ReplayGainTrack);
            }
            try
            {
                file2.WriteLine("Adding " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainAlbum) + " / " + Plugin.FilePropertyType.ReplayGainAlbum);
                tagToolsPlugin.propNamesIds.Add(mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainAlbum), Plugin.FilePropertyType.ReplayGainAlbum);
            }
            catch (ArgumentException)
            {
                wereErrors = true;
                file2.WriteLine("Cant add " + mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainAlbum) + " / " + Plugin.FilePropertyType.ReplayGainAlbum);
            }

            if (wereErrors)
            {
                MessageBox.Show("Some track property names are duplicated. See 'C:\\Windows\\Temp\\TagTools.PropNamesErrorLog.txt' file for details. Plugin is not properly initialized.");
            }

            file2.Close();


            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.Url, tagToolsPlugin.urlTagName);
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.Kind, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Kind));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.Format, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Format));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.Size, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Size));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.Channels, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Channels));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.SampleRate, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SampleRate));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.Bitrate, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Bitrate));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.DateModified, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateModified));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.DateAdded, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.DateAdded));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.LastPlayed, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.LastPlayed));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.PlayCount, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.PlayCount));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.SkipCount, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.SkipCount));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.Duration, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.Duration));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.ReplayGainTrack, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainTrack));
            tagToolsPlugin.propIdsNames.Add(Plugin.FilePropertyType.ReplayGainAlbum, mbApiInterface.Setting_GetFieldName((Plugin.MetaDataType)Plugin.FilePropertyType.ReplayGainAlbum));
        }

        public void display()
        {
            lock (tagToolsPlugin.openedForms)
            {
                //foreach (ToolsPluginTemplate form in tagToolsPlugin.openedForms)
                //{
                //    if (form.GetType() == this.GetType())
                //    {
                //        this.Dispose(true);

                //        if (form.Visible)
                //            form.Activate();
                //        else
                //            form.Show();

                //        return;
                //    }
                //}

                tagToolsPlugin.openedForms.Add(this);
            }

            this.Show();
        }

        private void serializedOperation()
        {
            bool taskWasStarted = false;

            tagToolsPlugin.initializeSbText();

            try
            {
                if (backgroundTaskIsCanceled)
                {
                    if (Plugin.SavedSettings.playCanceledSound)
                        System.Media.SystemSounds.Hand.Play();
                }
                else
                {
                    if (Plugin.SavedSettings.playStartedSound)
                        System.Media.SystemSounds.Exclamation.Play();

                    backgroundThread = Thread.CurrentThread;
                    backgroundThread.Priority = ThreadPriority.BelowNormal;


                    if (clickedButton != tagToolsPlugin.emptyButton)
                        Invoke(taskStarted);

                    taskWasStarted = true;
                    job();
                }
            }
            catch (ThreadAbortException)
            {
                backgroundTaskIsCanceled = true;
            }
            finally
            {
                lock (taskStarted)
                {
                    if (!Plugin.SavedSettings.dontPlayCompletedSound)
                        System.Media.SystemSounds.Asterisk.Play();

                    backgroundTaskIsScheduled = false;
                    backgroundTaskIsCanceled = false;

                    if (backgroundTaskIsNativeMB && taskWasStarted)
                    {
                        tagToolsPlugin.numberOfNativeMbBackgroundTasks--;
                    }
                }

                if (clickedButton != tagToolsPlugin.emptyButton)
                    Invoke(stopButtonClicked, new Object[] { this });

                tagToolsPlugin.refreshPanels(true);

                tagToolsPlugin.setResultingSbText();

                if (!Visible)
                {
                    if (Plugin.SavedSettings.closeShowHiddenWindows == 1)
                        Close();
                    else
                        Visible = true;
                }
            }
        }

        public void switchOperation(ThreadStart operation, Button clickedButtonParam, Button previewButtonParam, Button closeButtonParam, bool backgroundTaskIsNativeMbParam = true)
        {
            if (backgroundTaskIsScheduled && !backgroundTaskIsWorking())
            {
                if (backgroundTaskIsCanceled)
                {
                    backgroundTaskIsCanceled = false;

                    lock (tagToolsPlugin.openedForms)
                    {
                        if (backgroundTaskIsNativeMB)
                        {
                            tagToolsPlugin.numberOfNativeMbBackgroundTasks++;
                        }
                    }

                    queryingOrUpdatingButtonClick(this);
                }
                else
                {
                    backgroundTaskIsCanceled = true;

                    lock (tagToolsPlugin.openedForms)
                    {
                        if (backgroundTaskIsNativeMB)
                        {
                            tagToolsPlugin.numberOfNativeMbBackgroundTasks--;
                        }
                    }

                    stopButtonClicked(this);
                }
            }
            else if (backgroundTaskIsWorking())
            {
                backgroundTaskIsCanceled = true;
            }
            else
            {
                backgroundTaskIsNativeMB = backgroundTaskIsNativeMbParam;

                backgroundTaskIsCanceled = false;
                backgroundTaskIsScheduled = true;
                backgroundThread = null;

                clickedButton = clickedButtonParam;
                closeButton = closeButtonParam;
                previewButton = previewButtonParam;

                job = operation;

                if (backgroundTaskIsNativeMB)
                {
                    lock (tagToolsPlugin.openedForms)
                    {
                        tagToolsPlugin.numberOfNativeMbBackgroundTasks++;
                    }

                    mbApiInterface.MB_CreateBackgroundTask(serializedOperation, this);
                }
                else
                {
                    Thread tempThread = new Thread(serializedOperation);
                    tempThread.Start();
                }

                queryingOrUpdatingButtonClick(this);
            }
        }

        protected string getBackgroundTasksWarning()
        {
            if (tagToolsPlugin.numberOfNativeMbBackgroundTasks == 1)
                return tagToolsPlugin.ctlDirtyError1sf + tagToolsPlugin.numberOfNativeMbBackgroundTasks + tagToolsPlugin.ctlDirtyError2sf;
            else if (tagToolsPlugin.numberOfNativeMbBackgroundTasks > 1)
                return tagToolsPlugin.ctlDirtyError1mf + tagToolsPlugin.numberOfNativeMbBackgroundTasks + tagToolsPlugin.ctlDirtyError2mf;
            else
                return String.Empty;
        }

        public virtual void enableDisablePreviewOptionControls(bool enable)
        {
        }

        public virtual void enableQueryingButtons()
        {
        }

        public virtual void disableQueryingButtons()
        {
        }

        public virtual void enableQueryingOrUpdatingButtons()
        {
        }

        public virtual void disableQueryingOrUpdatingButtons()
        {
        }

        public void queryingOrUpdatingButtonClick(ToolsPluginTemplate clickedForm)
        {
            lock (tagToolsPlugin.openedForms)
            {
                foreach (ToolsPluginTemplate form in tagToolsPlugin.openedForms)
                {
                    if (backgroundTaskIsNativeMB && form != clickedForm && !(form.backgroundTaskIsNativeMB && form.backgroundTaskIsScheduled && !form.backgroundTaskIsCanceled))
                    {
                        form.disableQueryingButtons();
                    }
                }

                if (backgroundTaskIsNativeMB) //Updating operation
                {
                    clickedForm.enableQueryingButtons();
                    clickedForm.disableQueryingOrUpdatingButtons();

                    clickedButtonText = clickedButton.Text;
                    clickedButton.Text = tagToolsPlugin.cancelButtonName;
                    clickedButton.Enabled = true;

                    closeButtonText = closeButton.Text;
                    closeButton.Text = tagToolsPlugin.hideButtonName;
                    closeButton.Enabled = true;
                }
                else //Querying operation
                {
                    clickedForm.disableQueryingOrUpdatingButtons();

                    clickedButtonText = clickedButton.Text;
                    clickedButton.Text = tagToolsPlugin.stopButtonName;
                    clickedButton.Enabled = true;

                    closeButton.Enabled = false;
                }

                enableDisablePreviewOptionControls(false);
            }
        }

        public void stopButtonClickedMethod(ToolsPluginTemplate clickedForm)
        {
            lock (tagToolsPlugin.openedForms)
            {
                foreach (ToolsPluginTemplate form in tagToolsPlugin.openedForms)
                {
                    if (backgroundTaskIsNativeMB && form != clickedForm) //Updating operation
                    {
                        if (tagToolsPlugin.numberOfNativeMbBackgroundTasks > 0 && !(form.backgroundTaskIsNativeMB && form.backgroundTaskIsScheduled && !form.backgroundTaskIsCanceled))
                        {
                            form.disableQueryingButtons();
                        }
                        else
                        {
                            form.enableQueryingButtons();
                        }
                    }
                }

                clickedForm.disableQueryingButtons();
                clickedForm.enableQueryingOrUpdatingButtons();

                if (backgroundTaskIsNativeMB) //Updating operation
                {
                    clickedButton.Text = clickedButtonText;

                    if (previewIsGenerated)
                        previewButton.Text = tagToolsPlugin.clearButtonName;
                    else
                        previewButton.Text = tagToolsPlugin.previewButtonName;

                    if (backgroundTaskIsScheduled)
                        previewButton.Enabled = false;
                    else
                        closeButton.Text = closeButtonText;
                }
                else //Querying operation
                {
                    if (previewIsGenerated)
                        clickedButton.Text = tagToolsPlugin.clearButtonName;
                    else
                        clickedButton.Text = clickedButtonText;

                    closeButton.Enabled = true;
                }

                enableDisablePreviewOptionControls(true);
            }
        }

        private void taskStartedMethod()
        {
            lock (tagToolsPlugin.openedForms)
            {
                if (backgroundTaskIsNativeMB) //Updating operation
                {
                    enableQueryingButtons();

                    clickedButton.Text = tagToolsPlugin.stopButtonName;
                }
            }
        }

        protected void clickOnPreviewButton(DataGridView previewList, PrepareOperation prepareOperation, ThreadStart operation, Button clickedButtonParam, Button closeButtonParam)
        {
            if (!previewIsGenerated || backgroundTaskIsWorking())
            {
                if (prepareOperation())
                    switchOperation(operation, clickedButtonParam, clickedButtonParam, closeButtonParam, false);
            }
            else
            {
                previewList.Rows.Clear();
                previewIsGenerated = false;
                clickedButtonParam.Text = tagToolsPlugin.previewButtonName;
                enableDisablePreviewOptionControls(true);
            }
        }

        private void ToolsPluginTemplate_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (backgroundTaskIsScheduled)
            {
                e.Cancel = true;
                Hide();
            }
            else
            {
                lock (tagToolsPlugin.openedForms)
                {
                    tagToolsPlugin.openedForms.Remove(this);
                }

                string fullName = GetType().FullName;
                for (int i = 0; i < Plugin.NumberOfCommands; i++)
                {
                    if (Plugin.SavedSettings.forms[i] == fullName)
                    {
                        if (windowState == FormWindowState.Maximized)
                        {
                            Plugin.SavedSettings.sizesPositions[i].max = true;
                            break;
                        }
                        else if (windowState == FormWindowState.Minimized)
                        {
                            //Nothing changing in saved settings...
                            break;
                        }
                        else
                        {
                            Plugin.SavedSettings.sizesPositions[i].x = this.DesktopLocation.X;
                            Plugin.SavedSettings.sizesPositions[i].y = this.DesktopLocation.Y;
                            Plugin.SavedSettings.sizesPositions[i].w = this.Size.Width;
                            Plugin.SavedSettings.sizesPositions[i].h = this.Size.Height;
                            Plugin.SavedSettings.sizesPositions[i].max = false;
                            break;
                        }
                    }
                }
            }
        }

        private void ToolsPluginTemplate_Resize(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                windowWidth = this.RestoreBounds.Width;
                windowHeight = this.RestoreBounds.Height;

                Hide();
            }
            else
            {
                windowState = WindowState;
            }
        }

        private void ToolsPluginTemplate_VisibleChanged(object sender, EventArgs e)
        {
            if (Visible && windowWidth != 0)
            {
                WindowState = windowState;
                this.Width = windowWidth;
                this.Height = windowHeight;

                windowWidth = 0;
            }
        }

        private void ToolsPluginTemplate_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Space || e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab) && e.Shift == false && e.Control == false && e.Alt == false)
                e.SuppressKeyPress = true;
            else if ((e.KeyCode == Keys.C || e.KeyCode == Keys.V || e.KeyCode == Keys.X) && e.Shift == false && e.Control == true && e.Alt == false)
                e.SuppressKeyPress = true;
        }

        private void ToolsPluginTemplate_KeyUp(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.Space || e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab) && e.Shift == false && e.Control == false && e.Alt == false)
                e.SuppressKeyPress = true;
            else if ((e.KeyCode == Keys.C || e.KeyCode == Keys.V || e.KeyCode == Keys.X) && e.Shift == false && e.Control == true && e.Alt == false)
                e.SuppressKeyPress = true;
        }
    }
}
